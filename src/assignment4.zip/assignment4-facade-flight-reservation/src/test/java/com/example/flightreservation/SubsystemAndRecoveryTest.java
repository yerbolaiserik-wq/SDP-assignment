package com.example.flightreservation;

import com.example.flightreservation.domain.*;
import com.example.flightreservation.facade.*;
import com.example.flightreservation.finalization.*;
import com.example.flightreservation.persistence.CsvFileStore;
import com.example.flightreservation.reservation.*;
import com.example.flightreservation.ticketing.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

class SubsystemAndRecoveryTest {
    @TempDir Path dir;
    private ReservationRequest request(String seat, String fare, int bags, String loyalty, String meal) {
        return new ReservationRequest("Demo", "KC-921", seat, fare, bags, loyalty, meal);
    }
    @Test void subsystemAWorksWithoutFacade() throws Exception {
        var repo = new SeatMapRepository(new CsvFileStore(dir));
        var seats = new SeatReservationService(new SeatAvailabilityPolicy(), new FareCalculator(), repo);
        var hold = seats.reserveSeat(request("11A", "BUSINESS", 1, "LOY", "standard"));
        assertEquals(SeatHoldStatus.HELD, new SeatMapRepository(new CsvFileStore(dir)).findById(hold.reservationId()).orElseThrow().status());
        seats.releaseSeat(hold.reservationId());
        assertEquals(SeatHoldStatus.RELEASED, repo.findById(hold.reservationId()).orElseThrow().status());
    }
    @Test void subsystemBWorksWithoutFacadeAndValidatesBaggage() throws Exception {
        var repo = new TicketRepository(new CsvFileStore(dir));
        var issuer = new ETicketIssuer(new BaggageRulesEngine(), repo);
        assertThrows(ReservationException.class, () -> issuer.issueTicket("B-FAIL", request("11A", "ECONOMY", 2, "LOY", "standard")));
        assertTrue(repo.findAll().isEmpty());
        var ticket = issuer.issueTicket("B-OK", request("11B", "ECONOMY", 1, "LOY", "standard"));
        assertEquals(TicketStatus.ISSUED, ticket.status());
        issuer.voidTicket(ticket.reservationId());
        assertEquals(TicketStatus.VOIDED, new TicketRepository(new CsvFileStore(dir)).findByReservationId("B-OK").orElseThrow().status());
    }
    @Test void subsystemCWorksWithoutFacadeAndValidatesMeal() throws Exception {
        var repo = new ConfirmationRepository(new CsvFileStore(dir));
        var finalizer = new ReservationFinalizer(new LoyaltyProgram(), new MealPreferenceService(), repo);
        assertThrows(ReservationException.class, () -> finalizer.finalizeReservation("C-BAD", "TKT-C-BAD", 180, request("11A", "ECONOMY", 0, "LOY", "UNAVAILABLE")));
        assertTrue(repo.findAll().isEmpty());
        var confirmation = finalizer.finalizeReservation("C-OK", "TKT-C-OK", 180, request("11B", "ECONOMY", 0, "LOY", ""));
        assertEquals(ConfirmationStatus.FINALIZED, confirmation.status());
        assertEquals("STANDARD", confirmation.mealPreference());
        finalizer.cancelConfirmation("C-OK");
        assertEquals(ConfirmationStatus.CANCELLED, repo.findByReservationId("C-OK").orElseThrow().status());
    }
    @Test void restartAfterAAndBCommittedCompensatesBThenA() throws Exception {
        CsvFileStore store = new CsvFileStore(dir);
        var repo = new SeatMapRepository(store);
        var hold = new SeatReservationService(new SeatAvailabilityPolicy(), new FareCalculator(), repo).reserveSeat(request("18C", "ECONOMY", 1, "LOY", "standard"));
        new ETicketIssuer(new BaggageRulesEngine(), new TicketRepository(store)).issueTicket(hold.reservationId(), request("18C", "ECONOMY", 1, "LOY", "standard"));
        new ChainProgressRepository(store).save(new ReservationProgress(hold.reservationId(), ChainStatus.PENDING_FINALIZATION, "Crash after B persisted"));
        assertEquals(1, new ApplicationServices(dir).adminFacade().recoverIncompleteChains());
        assertEquals(TicketStatus.VOIDED, new TicketRepository(new CsvFileStore(dir)).findByReservationId(hold.reservationId()).orElseThrow().status());
        assertEquals(SeatHoldStatus.RELEASED, new SeatMapRepository(new CsvFileStore(dir)).findById(hold.reservationId()).orElseThrow().status());
        assertEquals(ChainStatus.COMPENSATED, new ChainProgressRepository(new CsvFileStore(dir)).findById(hold.reservationId()).orElseThrow().status());
        assertEquals(0, new ApplicationServices(dir).adminFacade().recoverIncompleteChains());
    }
    @Test void errorsAtAProduceNoPersistedChain() throws Exception {
        var services = new ApplicationServices(dir);
        assertThrows(ReservationException.class, () -> services.reservationFacade().reserveFlight(request("0A", "ECONOMY", 1, "LOY", "standard")));
        assertTrue(new ChainProgressRepository(new CsvFileStore(dir)).findAll().isEmpty());
        assertTrue(new SeatMapRepository(new CsvFileStore(dir)).findAll().isEmpty());
    }
    @Test void statesRejectIllegalTransitions() throws Exception {
        SeatHold hold = new SeatHold("A", "Person", "F", "1A", 10);
        assertThrows(ReservationException.class, hold::release);
        hold.hold(); assertThrows(ReservationException.class, hold::hold);
        TicketOrder ticket = new TicketOrder("B", "TKT-B", 0);
        assertThrows(ReservationException.class, ticket::voidTicket);
        ticket.issue(); assertThrows(ReservationException.class, ticket::issue);
        FlightConfirmation confirmation = new FlightConfirmation("C", "CNF-C", 0, "STANDARD");
        assertThrows(ReservationException.class, confirmation::cancel);
        confirmation.finalizeConfirmation(); assertThrows(ReservationException.class, confirmation::finalizeConfirmation);
    }
}
