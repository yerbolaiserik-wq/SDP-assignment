package com.example.flightreservation;

import com.example.flightreservation.facade.FlightReservationFacade;
import com.example.flightreservation.facade.ChainProgressRepository;
import com.example.flightreservation.facade.ChainStatus;
import com.example.flightreservation.facade.ReservationProgress;
import com.example.flightreservation.domain.ReservationException;
import com.example.flightreservation.domain.ReservationRequest;
import com.example.flightreservation.persistence.CsvFileStore;
import com.example.flightreservation.reservation.FareCalculator;
import com.example.flightreservation.reservation.SeatAvailabilityPolicy;
import com.example.flightreservation.reservation.SeatHold;
import com.example.flightreservation.reservation.SeatMapRepository;
import com.example.flightreservation.reservation.SeatReservationService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class FlightReservationFacadeTest {
    @TempDir
    Path tempDir;

    @Test
    void bFailureAfterSeatHoldCompensatesSeatOnly() {
        FlightTestDsl dsl = aCleanFlightStore();
        FlightReservationFacade facade = dsl.services.reservationFacade();

        assertThrows(ReservationException.class, () ->
                facade.reserveFlight(dsl.requestWithPassenger("FAIL_TICKET")));

        String state = dsl.services.adminFacade().inspectState();
        assertTrue(state.contains("RELEASED"));
        assertTrue(state.contains("COMPENSATED"));
        assertTrue(!state.contains("ISSUED"));
    }

    @Test
    void cFailureAfterTicketIssueVoidsTicketThenReleasesSeat() {
        FlightTestDsl dsl = aCleanFlightStore();
        FlightReservationFacade facade = dsl.services.reservationFacade();

        assertThrows(ReservationException.class, () ->
                facade.reserveFlight(dsl.requestWithLoyalty("REJECT")));

        String state = dsl.services.adminFacade().inspectState();
        assertTrue(state.contains("VOIDED"));
        assertTrue(state.contains("RELEASED"));
        assertTrue(state.contains("COMPENSATED"));
    }

    @Test
    void persistedPendingChainCanBeCompensatedAfterRestart() throws ReservationException {
        CsvFileStore store = new CsvFileStore(tempDir);
        store.clear();
        SeatMapRepository seatMapRepository = new SeatMapRepository(store);
        SeatReservationService seatService = new SeatReservationService(
                new SeatAvailabilityPolicy(),
                new FareCalculator(),
                seatMapRepository);
        ChainProgressRepository progressRepository = new ChainProgressRepository(store);

        SeatHold hold = seatService.reserveSeat(new ReservationRequest("Aigerim", "KC-921", "18F", "ECONOMY", 1, "LOY-44", "standard"));
        progressRepository.save(new ReservationProgress(hold.reservationId(), ChainStatus.PENDING_TICKET, "Restart happened before ticketing."));

        FlightTestDsl afterRestart = usingExistingFlightStore();
        afterRestart.services.adminFacade().compensateFromPersistedState(hold.reservationId());

        String persistedState = afterRestart.services.adminFacade().inspectState();
        assertTrue(persistedState.contains("RELEASED"));
        assertTrue(persistedState.contains("COMPENSATED"));
    }

    @Test
    void successfulReservationPersistsAllThreeStages() throws ReservationException {
        FlightTestDsl dsl = aCleanFlightStore();
        var result = dsl.services.reservationFacade().reserveFlight(dsl.requestWithPassenger("Dana"));
        String diskState = usingExistingFlightStore().services.adminFacade().inspectState();
        assertTrue(diskState.contains(result.reservationId()));
        assertTrue(diskState.contains("HELD"));
        assertTrue(diskState.contains("ISSUED"));
        assertTrue(diskState.contains("FINALIZED"));
        assertTrue(diskState.contains("COMPLETED"));
    }

    @Test
    void duplicateSeatRejectedBeforeAnotherHold() throws ReservationException {
        FlightTestDsl dsl = aCleanFlightStore();
        dsl.services.reservationFacade().reserveFlight(dsl.requestWithPassenger("Dana"));
        assertThrows(ReservationException.class, () ->
                dsl.services.reservationFacade().reserveFlight(dsl.requestWithPassenger("Other")));
        assertTrue(dsl.services.adminFacade().inspectState().contains("COMPLETED"));
    }

    @Test
    void restartRecoversPersistedPendingTicketAndSeat() throws ReservationException {
        FlightTestDsl dsl = aCleanFlightStore();
        var hold = dsl.services.reservationFacade().reserveFlight(dsl.requestWithPassenger("Dana"));
        var progress = new ChainProgressRepository(new CsvFileStore(tempDir));
        progress.save(new ReservationProgress(hold.reservationId(), ChainStatus.PENDING_FINALIZATION, "Simulated crash"));
        var newProcess = usingExistingFlightStore();
        org.junit.jupiter.api.Assertions.assertEquals(1, newProcess.services.adminFacade().recoverIncompleteChains());
        var diskState = newProcess.services.adminFacade().inspectState();
        assertTrue(diskState.contains("CANCELLED"));
        assertTrue(diskState.contains("VOIDED"));
        assertTrue(diskState.contains("RELEASED"));
    }

    private FlightTestDsl aCleanFlightStore() {
        ApplicationServices services = new ApplicationServices(tempDir);
        services.resetStore();
        return new FlightTestDsl(services);
    }

    private FlightTestDsl usingExistingFlightStore() {
        return new FlightTestDsl(new ApplicationServices(tempDir));
    }

    private static class FlightTestDsl {
        private final ApplicationServices services;

        private FlightTestDsl(ApplicationServices services) {
            this.services = services;
        }

        private ReservationRequest requestWithPassenger(String passengerName) {
            return new ReservationRequest(passengerName, "KC-921", "12A", "ECONOMY", 1, "LOY-44", "standard");
        }

        private ReservationRequest requestWithLoyalty(String loyaltyId) {
            return new ReservationRequest("Aigerim", "KC-921", "12B", "PREMIUM", 1, loyaltyId, "standard");
        }
    }
}
