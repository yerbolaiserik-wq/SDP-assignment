package com.example.flightreservation.reservation;

import com.example.flightreservation.domain.ReservationException;

public class FareCalculator {
    public double calculate(String fareClass) throws ReservationException {
        return switch (fareClass.toUpperCase()) {
            case "ECONOMY" -> 180.00;
            case "PREMIUM" -> 320.00;
            case "BUSINESS" -> 560.00;
            default -> throw new ReservationException("Unsupported fare class: " + fareClass);
        };
    }
}
