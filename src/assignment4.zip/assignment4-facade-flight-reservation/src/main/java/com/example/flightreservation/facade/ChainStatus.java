package com.example.flightreservation.facade;

public enum ChainStatus {
    PENDING_TICKET,
    PENDING_FINALIZATION,
    COMPLETED,
    COMPENSATED
}
