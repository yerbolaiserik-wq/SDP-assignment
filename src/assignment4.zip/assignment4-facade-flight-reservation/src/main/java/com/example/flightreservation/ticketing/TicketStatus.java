package com.example.flightreservation.ticketing;

public enum TicketStatus {
    NEW,
    ISSUED,
    VOIDED
}
