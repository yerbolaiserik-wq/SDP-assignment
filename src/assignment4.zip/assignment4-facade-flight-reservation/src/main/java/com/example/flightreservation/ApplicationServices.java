package com.example.flightreservation;

import com.example.flightreservation.facade.ChainProgressRepository;
import com.example.flightreservation.facade.FlightReservationFacade;
import com.example.flightreservation.facade.ReservationAdminFacade;
import com.example.flightreservation.finalization.ConfirmationRepository;
import com.example.flightreservation.finalization.LoyaltyProgram;
import com.example.flightreservation.finalization.MealPreferenceService;
import com.example.flightreservation.finalization.ReservationFinalizer;
import com.example.flightreservation.persistence.CsvFileStore;
import com.example.flightreservation.reservation.FareCalculator;
import com.example.flightreservation.reservation.SeatAvailabilityPolicy;
import com.example.flightreservation.reservation.SeatMapRepository;
import com.example.flightreservation.reservation.SeatReservationService;
import com.example.flightreservation.ticketing.BaggageRulesEngine;
import com.example.flightreservation.ticketing.ETicketIssuer;
import com.example.flightreservation.ticketing.TicketRepository;

import java.nio.file.Path;

public class ApplicationServices {
    private final CsvFileStore store;
    private final SeatMapRepository seatMapRepository;
    private final TicketRepository ticketRepository;
    private final ConfirmationRepository confirmationRepository;
    private final ChainProgressRepository progressRepository;
    private final SeatReservationService seatReservationService;
    private final ETicketIssuer ticketIssuer;
    private final ReservationFinalizer reservationFinalizer;

    public ApplicationServices(Path dataDirectory) {
        store = new CsvFileStore(dataDirectory);
        seatMapRepository = new SeatMapRepository(store);
        ticketRepository = new TicketRepository(store);
        confirmationRepository = new ConfirmationRepository(store);
        progressRepository = new ChainProgressRepository(store);
        seatReservationService = new SeatReservationService(new SeatAvailabilityPolicy(), new FareCalculator(), seatMapRepository);
        ticketIssuer = new ETicketIssuer(new BaggageRulesEngine(), ticketRepository);
        reservationFinalizer = new ReservationFinalizer(new LoyaltyProgram(), new MealPreferenceService(), confirmationRepository);
    }

    public FlightReservationFacade reservationFacade() {
        return new FlightReservationFacade(seatReservationService, ticketIssuer, reservationFinalizer, progressRepository, adminFacade());
    }

    public ReservationAdminFacade adminFacade() {
        return new ReservationAdminFacade(
                seatMapRepository,
                ticketRepository,
                confirmationRepository,
                seatReservationService,
                ticketIssuer,
                reservationFinalizer,
                progressRepository);
    }

    public void resetStore() {
        store.clear();
    }
}
