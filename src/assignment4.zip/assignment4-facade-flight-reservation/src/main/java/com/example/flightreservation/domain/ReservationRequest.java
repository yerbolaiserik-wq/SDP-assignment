package com.example.flightreservation.domain;

public record ReservationRequest(
        String passengerName,
        String flightNumber,
        String seatNumber,
        String fareClass,
        int checkedBags,
        String loyaltyId,
        String mealPreference
) {
}
