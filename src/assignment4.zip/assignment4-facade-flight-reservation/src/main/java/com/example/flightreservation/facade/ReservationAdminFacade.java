package com.example.flightreservation.facade;

import com.example.flightreservation.domain.ReservationException;

import com.example.flightreservation.finalization.ConfirmationRepository;
import com.example.flightreservation.finalization.ConfirmationStatus;
import com.example.flightreservation.finalization.ReservationFinalizer;
import com.example.flightreservation.reservation.SeatHoldStatus;
import com.example.flightreservation.reservation.SeatMapRepository;
import com.example.flightreservation.reservation.SeatReservationService;
import com.example.flightreservation.ticketing.ETicketIssuer;
import com.example.flightreservation.ticketing.TicketRepository;
import com.example.flightreservation.ticketing.TicketStatus;

public class ReservationAdminFacade {
    private final SeatMapRepository seatMapRepository;
    private final TicketRepository ticketRepository;
    private final ConfirmationRepository confirmationRepository;
    private final SeatReservationService seatReservationService;
    private final ETicketIssuer ticketIssuer;
    private final ReservationFinalizer reservationFinalizer;
    private final ChainProgressRepository progressRepository;

    public ReservationAdminFacade(
            SeatMapRepository seatMapRepository,
            TicketRepository ticketRepository,
            ConfirmationRepository confirmationRepository,
            SeatReservationService seatReservationService,
            ETicketIssuer ticketIssuer,
            ReservationFinalizer reservationFinalizer,
            ChainProgressRepository progressRepository) {
        this.seatMapRepository = seatMapRepository;
        this.ticketRepository = ticketRepository;
        this.confirmationRepository = confirmationRepository;
        this.seatReservationService = seatReservationService;
        this.ticketIssuer = ticketIssuer;
        this.reservationFinalizer = reservationFinalizer;
        this.progressRepository = progressRepository;
    }

    public String inspectState() {
        StringBuilder view = new StringBuilder();
        view.append("Seat holds:\n");
        seatMapRepository.findAll().forEach(hold -> view.append("  ")
                .append(hold.reservationId()).append(" ")
                .append(hold.flightNumber()).append(" ")
                .append(hold.seatNumber()).append(" ")
                .append(hold.status()).append("\n"));

        view.append("Tickets:\n");
        ticketRepository.findAll().forEach(ticket -> view.append("  ")
                .append(ticket.reservationId()).append(" ")
                .append(ticket.ticketCode()).append(" ")
                .append(ticket.status()).append("\n"));

        view.append("Confirmations:\n");
        confirmationRepository.findAll().forEach(confirmation -> view.append("  ")
                .append(confirmation.reservationId()).append(" ")
                .append(confirmation.confirmationCode()).append(" ")
                .append(confirmation.status()).append("\n"));

        view.append("Chain progress:\n");
        progressRepository.findAll().forEach(progress -> view.append("  ")
                .append(progress.reservationId()).append(" ")
                .append(progress.status()).append(" - ")
                .append(progress.note()).append("\n"));

        return view.toString();
    }

    /** Called after a restart to reconcile unfinished chains using persisted entity states. */
    public int recoverIncompleteChains() throws ReservationException {
        int recovered = 0;
        for (ReservationProgress progress : progressRepository.findAll()) {
            if (progress.status() == ChainStatus.PENDING_TICKET ||
                    progress.status() == ChainStatus.PENDING_FINALIZATION) {
                compensateFromPersistedState(progress.reservationId());
                recovered++;
            }
        }
        return recovered;
    }

    public void compensateFromPersistedState(String reservationId) throws ReservationException {
        ReservationProgress progress = progressRepository.findById(reservationId)
                .orElseThrow(() -> new ReservationException("No chain progress exists for: " + reservationId));

        if (progress.status() == ChainStatus.COMPENSATED) {
            return;
        }

        // Inspect the committed entity statuses on disk rather than trusting chain progress alone.
        var confirmation = confirmationRepository.findByReservationId(reservationId);
        if (confirmation.isPresent() && confirmation.get().status() == ConfirmationStatus.FINALIZED) {
            reservationFinalizer.cancelConfirmation(reservationId);
        }
        var ticket = ticketRepository.findByReservationId(reservationId);
        if (ticket.isPresent() && ticket.get().status() == TicketStatus.ISSUED) {
            ticketIssuer.voidTicket(reservationId);
        }
        var hold = seatMapRepository.findById(reservationId);
        if (hold.isPresent() && hold.get().status() == SeatHoldStatus.HELD) {
            seatReservationService.releaseSeat(reservationId);
        }

        progressRepository.save(new ReservationProgress(reservationId, ChainStatus.COMPENSATED, "Manual compensation completed from persisted state."));
    }
}
