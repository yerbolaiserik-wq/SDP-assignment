package com.example.flightreservation.reservation;

import com.example.flightreservation.domain.ReservationException;

public class SeatHold {
    private final String reservationId;
    private final String passengerName;
    private final String flightNumber;
    private final String seatNumber;
    private final double fare;
    private SeatHoldStatus status;

    public SeatHold(String reservationId, String passengerName, String flightNumber, String seatNumber, double fare) {
        this(reservationId, passengerName, flightNumber, seatNumber, fare, SeatHoldStatus.NEW);
    }

    public SeatHold(String reservationId, String passengerName, String flightNumber, String seatNumber, double fare, SeatHoldStatus status) {
        this.reservationId = reservationId;
        this.passengerName = passengerName;
        this.flightNumber = flightNumber;
        this.seatNumber = seatNumber;
        this.fare = fare;
        this.status = status;
    }

    public void hold() throws ReservationException {
        if (status != SeatHoldStatus.NEW) {
            throw new ReservationException("Seat can only move from NEW to HELD.");
        }
        status = SeatHoldStatus.HELD;
    }

    public void release() throws ReservationException {
        if (status != SeatHoldStatus.HELD) {
            throw new ReservationException("Only a HELD seat can be released.");
        }
        status = SeatHoldStatus.RELEASED;
    }

    public String reservationId() {
        return reservationId;
    }

    public String passengerName() {
        return passengerName;
    }

    public String flightNumber() {
        return flightNumber;
    }

    public String seatNumber() {
        return seatNumber;
    }

    public double fare() {
        return fare;
    }

    public SeatHoldStatus status() {
        return status;
    }

    public String toRow() {
        return String.join("|",
                reservationId,
                passengerName,
                flightNumber,
                seatNumber,
                Double.toString(fare),
                status.name());
    }

    public static SeatHold fromRow(String row) {
        String[] parts = row.split("\\|", -1);
        return new SeatHold(
                parts[0],
                parts[1],
                parts[2],
                parts[3],
                Double.parseDouble(parts[4]),
                SeatHoldStatus.valueOf(parts[5]));
    }
}
