package com.example.flightreservation.facade;

import com.example.flightreservation.domain.ReservationException;

import com.example.flightreservation.domain.ReservationRequest;

import com.example.flightreservation.finalization.FlightConfirmation;
import com.example.flightreservation.finalization.ReservationFinalizer;
import com.example.flightreservation.reservation.SeatHold;
import com.example.flightreservation.reservation.SeatReservationService;
import com.example.flightreservation.ticketing.ETicketIssuer;
import com.example.flightreservation.ticketing.TicketOrder;

public class FlightReservationFacade {
    private final SeatReservationService seatReservationService;
    private final ETicketIssuer ticketIssuer;
    private final ReservationFinalizer reservationFinalizer;
    private final ChainProgressRepository progressRepository;
    private final ReservationAdminFacade adminFacade;

    public FlightReservationFacade(
            SeatReservationService seatReservationService,
            ETicketIssuer ticketIssuer,
            ReservationFinalizer reservationFinalizer,
            ChainProgressRepository progressRepository, ReservationAdminFacade adminFacade) {
        this.seatReservationService = seatReservationService;
        this.ticketIssuer = ticketIssuer;
        this.reservationFinalizer = reservationFinalizer;
        this.progressRepository = progressRepository;
        this.adminFacade = adminFacade;
    }

    public ReservationResult reserveFlight(ReservationRequest request) throws ReservationException {
        SeatHold hold = seatReservationService.reserveSeat(request);
        progressRepository.save(new ReservationProgress(hold.reservationId(), ChainStatus.PENDING_TICKET, "Seat was held."));

        TicketOrder ticket;
        try {
            ticket = ticketIssuer.issueTicket(hold.reservationId(), request);
            progressRepository.save(new ReservationProgress(hold.reservationId(), ChainStatus.PENDING_FINALIZATION, "Ticket was issued."));
        } catch (ReservationException error) {
            try {
                adminFacade.compensateFromPersistedState(hold.reservationId());
            } catch (ReservationException compensationError) {
                error.addSuppressed(compensationError);
            }
            throw error;
        }

        try {
            FlightConfirmation confirmation = reservationFinalizer.finalizeReservation(hold.reservationId(), ticket.ticketCode(), hold.fare(), request);
            progressRepository.save(new ReservationProgress(hold.reservationId(), ChainStatus.COMPLETED, "Reservation completed."));
            return new ReservationResult(hold.reservationId(), ticket.ticketCode(), confirmation.confirmationCode(), hold.fare());
        } catch (ReservationException error) {
            try {
                adminFacade.compensateFromPersistedState(hold.reservationId());
            } catch (ReservationException compensationError) {
                error.addSuppressed(compensationError);
            }
            throw error;
        }
    }
}
