package com.example.flightreservation.finalization;

import com.example.flightreservation.domain.ReservationException;
import com.example.flightreservation.domain.ReservationRequest;

public class LoyaltyProgram {
    public int calculatePoints(ReservationRequest request, double fare) throws ReservationException {
        if (request.loyaltyId().equalsIgnoreCase("REJECT")) {
            throw new ReservationException("Loyalty program rejected the passenger after ticketing completed.");
        }
        return (int) Math.round(fare / 10.0);
    }
}
