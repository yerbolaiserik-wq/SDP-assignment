package com.example.flightreservation.persistence;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CsvFileStore {
    private final Path dataDirectory;

    public CsvFileStore(Path dataDirectory) {
        this.dataDirectory = dataDirectory;
        try {
            Files.createDirectories(dataDirectory);
        } catch (IOException error) {
            throw new UncheckedIOException(error);
        }
    }

    public synchronized void upsert(String fileName, String id, String row) {
        List<String> rows = readRows(fileName);
        List<String> updatedRows = new ArrayList<>();
        boolean replaced = false;

        for (String existingRow : rows) {
            if (existingRow.startsWith(id + "|")) {
                updatedRows.add(row);
                replaced = true;
            } else {
                updatedRows.add(existingRow);
            }
        }

        if (!replaced) {
            updatedRows.add(row);
        }

        writeRows(fileName, updatedRows);
    }

    public synchronized Optional<String> findById(String fileName, String id) {
        return readRows(fileName).stream()
                .filter(row -> row.startsWith(id + "|"))
                .findFirst();
    }

    public synchronized List<String> readRows(String fileName) {
        Path file = dataDirectory.resolve(fileName);
        if (!Files.exists(file)) {
            return new ArrayList<>();
        }
        try {
            return new ArrayList<>(Files.readAllLines(file, StandardCharsets.UTF_8));
        } catch (IOException error) {
            throw new UncheckedIOException(error);
        }
    }

    public synchronized void clear() {
        try {
            if (!Files.exists(dataDirectory)) {
                return;
            }
            try (var paths = Files.list(dataDirectory)) {
                paths.filter(Files::isRegularFile).forEach(path -> {
                    try {
                        Files.deleteIfExists(path);
                    } catch (IOException error) {
                        throw new UncheckedIOException(error);
                    }
                });
            }
        } catch (IOException error) {
            throw new UncheckedIOException(error);
        }
    }

    private void writeRows(String fileName, List<String> rows) {
        Path file = dataDirectory.resolve(fileName);
        try {
            Files.write(file, rows, StandardCharsets.UTF_8);
        } catch (IOException error) {
            throw new UncheckedIOException(error);
        }
    }
}
