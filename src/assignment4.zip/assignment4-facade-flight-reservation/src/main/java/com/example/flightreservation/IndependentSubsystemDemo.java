package com.example.flightreservation;

import com.example.flightreservation.domain.ReservationRequest;
import com.example.flightreservation.domain.ReservationException;
import com.example.flightreservation.persistence.CsvFileStore;
import com.example.flightreservation.reservation.*;
import com.example.flightreservation.ticketing.*;
import com.example.flightreservation.finalization.*;
import java.nio.file.Path;
import java.nio.file.Files;
import java.io.IOException;

/** Shows each subsystem can be used independently, without a facade or another subsystem. */
public final class IndependentSubsystemDemo {
    private IndependentSubsystemDemo() {}
    public static void main(String[] args) throws Exception { run(); }
    public static void run() throws ReservationException {
        try {
            Path dir = Files.createTempDirectory("a4-subsystem-demo-");
            CsvFileStore store = new CsvFileStore(dir);
            ReservationRequest request = new ReservationRequest("Demo", "KC-921", "22D", "ECONOMY", 1, "LOY-44", "standard");
            // A independently creates its own persisted seat hold.
            SeatReservationService seats = new SeatReservationService(new SeatAvailabilityPolicy(), new FareCalculator(), new SeatMapRepository(store));
            SeatHold hold = seats.reserveSeat(request);
            System.out.println("Subsystem A: " + hold.status() + " persisted=" + new SeatMapRepository(store).findById(hold.reservationId()).isPresent());
            // B accepts an ID, not an A entity. No A subsystem involved in constructing B.
            ETicketIssuer tickets = new ETicketIssuer(new BaggageRulesEngine(), new TicketRepository(store));
            TicketOrder ticket = tickets.issueTicket("INDEPENDENT-B", request);
            System.out.println("Subsystem B: " + ticket.status() + " persisted=" + new TicketRepository(store).findByReservationId("INDEPENDENT-B").isPresent());
            // C accepts only simple values, not A or B entities.
            ReservationFinalizer finalizer = new ReservationFinalizer(new LoyaltyProgram(), new MealPreferenceService(), new ConfirmationRepository(store));
            FlightConfirmation confirmation = finalizer.finalizeReservation("INDEPENDENT-C", "TKT-INDEPENDENT-C", 180.0, request);
            System.out.println("Subsystem C: " + confirmation.status() + " persisted=" + new ConfirmationRepository(store).findByReservationId("INDEPENDENT-C").isPresent());
        } catch (IOException error) {
            throw new IllegalStateException("Unable to prepare isolated subsystem demo store", error);
        }
    }
}
