package com.example.flightreservation.ticketing;

import com.example.flightreservation.domain.ReservationException;
import com.example.flightreservation.domain.ReservationRequest;

public class ETicketIssuer {
    private final BaggageRulesEngine baggageRulesEngine;
    private final TicketRepository repository;

    public ETicketIssuer(BaggageRulesEngine baggageRulesEngine, TicketRepository repository) {
        this.baggageRulesEngine = baggageRulesEngine;
        this.repository = repository;
    }

    public TicketOrder issueTicket(String reservationId, ReservationRequest request) throws ReservationException {
        if (request.passengerName().equalsIgnoreCase("FAIL_TICKET")) {
            throw new ReservationException("Ticket issuer was unavailable after the seat was held.");
        }

        baggageRulesEngine.validate(request);
        TicketOrder ticket = new TicketOrder(reservationId, "TKT-" + reservationId.substring(4), request.checkedBags());
        ticket.issue();
        repository.save(ticket);
        return ticket;
    }

    public void voidTicket(String reservationId) throws ReservationException {
        TicketOrder ticket = repository.findByReservationId(reservationId)
                .orElseThrow(() -> new ReservationException("Ticket was not found: " + reservationId));
        if (ticket.status() == TicketStatus.VOIDED) {
            return;
        }
        ticket.voidTicket();
        repository.save(ticket);
    }
}
