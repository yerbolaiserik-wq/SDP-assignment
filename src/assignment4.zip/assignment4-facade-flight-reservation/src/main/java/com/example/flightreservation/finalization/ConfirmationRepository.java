package com.example.flightreservation.finalization;

import com.example.flightreservation.persistence.CsvFileStore;

import java.util.List;
import java.util.Optional;

public class ConfirmationRepository {
    private static final String FILE_NAME = "confirmations.csv";
    private final CsvFileStore store;

    public ConfirmationRepository(CsvFileStore store) {
        this.store = store;
    }

    public void save(FlightConfirmation confirmation) {
        store.upsert(FILE_NAME, confirmation.reservationId(), confirmation.toRow());
    }

    public Optional<FlightConfirmation> findByReservationId(String reservationId) {
        return store.findById(FILE_NAME, reservationId).map(FlightConfirmation::fromRow);
    }

    public List<FlightConfirmation> findAll() {
        return store.readRows(FILE_NAME).stream().map(FlightConfirmation::fromRow).toList();
    }
}
