package com.example.flightreservation.reservation;

import com.example.flightreservation.domain.ReservationException;

public class SeatAvailabilityPolicy {
    public void validate(String seatNumber) throws ReservationException {
        if (seatNumber == null || seatNumber.isBlank()) {
            throw new ReservationException("Seat number is required before the chain starts.");
        }
        if (seatNumber.equalsIgnoreCase("0A")) {
            throw new ReservationException("Seat 0A is blocked before any subsystem commits.");
        }
    }
}
