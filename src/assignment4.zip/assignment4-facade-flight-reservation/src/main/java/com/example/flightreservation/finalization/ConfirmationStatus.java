package com.example.flightreservation.finalization;

public enum ConfirmationStatus {
    NEW,
    FINALIZED,
    CANCELLED
}
