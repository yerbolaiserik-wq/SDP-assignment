package com.example.flightreservation.finalization;

import com.example.flightreservation.domain.ReservationException;
import com.example.flightreservation.domain.ReservationRequest;

public class ReservationFinalizer {
    private final LoyaltyProgram loyaltyProgram;
    private final MealPreferenceService mealPreferenceService;
    private final ConfirmationRepository repository;

    public ReservationFinalizer(LoyaltyProgram loyaltyProgram, MealPreferenceService mealPreferenceService, ConfirmationRepository repository) {
        this.loyaltyProgram = loyaltyProgram;
        this.mealPreferenceService = mealPreferenceService;
        this.repository = repository;
    }

    public FlightConfirmation finalizeReservation(String reservationId, String ticketCode, double fare, ReservationRequest request) throws ReservationException {
        int points = loyaltyProgram.calculatePoints(request, fare);
        String meal = mealPreferenceService.normalizeMeal(request.mealPreference());
        FlightConfirmation confirmation = new FlightConfirmation(
                reservationId,
                "CNF-" + ticketCode.substring(4),
                points,
                meal);
        confirmation.finalizeConfirmation();
        repository.save(confirmation);
        return confirmation;
    }

    public void cancelConfirmation(String reservationId) throws ReservationException {
        FlightConfirmation confirmation = repository.findByReservationId(reservationId)
                .orElseThrow(() -> new ReservationException("Confirmation was not found: " + reservationId));
        if (confirmation.status() == ConfirmationStatus.CANCELLED) {
            return;
        }
        confirmation.cancel();
        repository.save(confirmation);
    }
}
