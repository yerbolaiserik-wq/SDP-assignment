package com.example.flightreservation.ticketing;

import com.example.flightreservation.domain.ReservationException;
import com.example.flightreservation.domain.ReservationRequest;

public class BaggageRulesEngine {
    public void validate(ReservationRequest request) throws ReservationException {
        if (request.checkedBags() < 0) {
            throw new ReservationException("Checked bag count cannot be negative.");
        }
        if (request.checkedBags() > 2) {
            throw new ReservationException("Ticketing rejected the request because too many bags were added.");
        }
        if (request.fareClass().equalsIgnoreCase("ECONOMY") && request.checkedBags() > 1) {
            throw new ReservationException("Economy fare allows only one checked bag.");
        }
    }
}
