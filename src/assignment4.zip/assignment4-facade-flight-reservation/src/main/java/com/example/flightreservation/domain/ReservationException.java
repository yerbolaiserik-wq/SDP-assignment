package com.example.flightreservation.domain;

public class ReservationException extends Exception {
    public ReservationException(String message) {
        super(message);
    }
}
