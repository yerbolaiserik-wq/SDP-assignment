package com.example.flightreservation.facade;

import com.example.flightreservation.persistence.CsvFileStore;

import java.util.List;
import java.util.Optional;

public class ChainProgressRepository {
    private static final String FILE_NAME = "chain-progress.csv";
    private final CsvFileStore store;

    public ChainProgressRepository(CsvFileStore store) {
        this.store = store;
    }

    public void save(ReservationProgress progress) {
        store.upsert(FILE_NAME, progress.reservationId(), progress.toRow());
    }

    public Optional<ReservationProgress> findById(String reservationId) {
        return store.findById(FILE_NAME, reservationId).map(ReservationProgress::fromRow);
    }

    public List<ReservationProgress> findAll() {
        return store.readRows(FILE_NAME).stream().map(ReservationProgress::fromRow).toList();
    }
}
