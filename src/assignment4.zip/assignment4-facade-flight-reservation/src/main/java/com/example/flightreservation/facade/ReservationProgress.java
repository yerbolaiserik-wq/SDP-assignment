package com.example.flightreservation.facade;

public record ReservationProgress(String reservationId, ChainStatus status, String note) {
    public String toRow() {
        return String.join("|", reservationId, status.name(), note.replace("|", "/"));
    }

    public static ReservationProgress fromRow(String row) {
        String[] parts = row.split("\\|", -1);
        return new ReservationProgress(parts[0], ChainStatus.valueOf(parts[1]), parts[2]);
    }
}
