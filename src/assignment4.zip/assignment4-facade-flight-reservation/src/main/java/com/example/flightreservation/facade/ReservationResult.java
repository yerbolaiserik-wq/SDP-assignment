package com.example.flightreservation.facade;

public record ReservationResult(
        String reservationId,
        String ticketCode,
        String confirmationCode,
        double fare
) {
}
