package com.example.flightreservation.reservation;

import com.example.flightreservation.persistence.CsvFileStore;

import java.util.List;
import java.util.Optional;

public class SeatMapRepository {
    private static final String FILE_NAME = "seat-holds.csv";
    private final CsvFileStore store;

    public SeatMapRepository(CsvFileStore store) {
        this.store = store;
    }

    public void save(SeatHold hold) {
        store.upsert(FILE_NAME, hold.reservationId(), hold.toRow());
    }

    public Optional<SeatHold> findById(String reservationId) {
        return store.findById(FILE_NAME, reservationId).map(SeatHold::fromRow);
    }

    public List<SeatHold> findAll() {
        return store.readRows(FILE_NAME).stream().map(SeatHold::fromRow).toList();
    }
}
