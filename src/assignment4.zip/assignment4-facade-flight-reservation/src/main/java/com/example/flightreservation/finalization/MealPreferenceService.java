package com.example.flightreservation.finalization;

import com.example.flightreservation.domain.ReservationException;

public class MealPreferenceService {
    public String normalizeMeal(String mealPreference) throws ReservationException {
        if (mealPreference.equalsIgnoreCase("UNAVAILABLE")) {
            throw new ReservationException("Requested meal became unavailable after ticketing completed.");
        }
        if (mealPreference.isBlank()) {
            return "STANDARD";
        }
        return mealPreference.toUpperCase();
    }
}
