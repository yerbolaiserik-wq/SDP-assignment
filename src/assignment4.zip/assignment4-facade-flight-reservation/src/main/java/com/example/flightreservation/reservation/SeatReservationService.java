package com.example.flightreservation.reservation;

import com.example.flightreservation.domain.ReservationException;
import com.example.flightreservation.domain.ReservationRequest;

import java.util.UUID;

public class SeatReservationService {
    private final SeatAvailabilityPolicy availabilityPolicy;
    private final FareCalculator fareCalculator;
    private final SeatMapRepository repository;

    public SeatReservationService(SeatAvailabilityPolicy availabilityPolicy, FareCalculator fareCalculator, SeatMapRepository repository) {
        this.availabilityPolicy = availabilityPolicy;
        this.fareCalculator = fareCalculator;
        this.repository = repository;
    }

    public SeatHold reserveSeat(ReservationRequest request) throws ReservationException {
        availabilityPolicy.validate(request.seatNumber());
        if (request.flightNumber() == null || request.flightNumber().isBlank() ||
                request.passengerName() == null || request.passengerName().isBlank()) {
            throw new ReservationException("Passenger and flight are required.");
        }
        boolean occupied = repository.findAll().stream().anyMatch(existing ->
                existing.status() == SeatHoldStatus.HELD &&
                existing.flightNumber().equalsIgnoreCase(request.flightNumber()) &&
                existing.seatNumber().equalsIgnoreCase(request.seatNumber()));
        if (occupied) throw new ReservationException("Seat is already held for this flight.");
        double fare = fareCalculator.calculate(request.fareClass());
        String reservationId = "RES-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        SeatHold hold = new SeatHold(reservationId, request.passengerName(), request.flightNumber(), request.seatNumber(), fare);
        hold.hold();
        repository.save(hold);
        return hold;
    }

    public void releaseSeat(String reservationId) throws ReservationException {
        SeatHold hold = repository.findById(reservationId)
                .orElseThrow(() -> new ReservationException("Seat hold was not found: " + reservationId));
        if (hold.status() == SeatHoldStatus.RELEASED) {
            return;
        }
        hold.release();
        repository.save(hold);
    }
}
