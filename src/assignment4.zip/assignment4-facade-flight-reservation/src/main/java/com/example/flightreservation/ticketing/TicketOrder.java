package com.example.flightreservation.ticketing;

import com.example.flightreservation.domain.ReservationException;

public class TicketOrder {
    private final String reservationId;
    private final String ticketCode;
    private final int checkedBags;
    private TicketStatus status;

    public TicketOrder(String reservationId, String ticketCode, int checkedBags) {
        this(reservationId, ticketCode, checkedBags, TicketStatus.NEW);
    }

    public TicketOrder(String reservationId, String ticketCode, int checkedBags, TicketStatus status) {
        this.reservationId = reservationId;
        this.ticketCode = ticketCode;
        this.checkedBags = checkedBags;
        this.status = status;
    }

    public void issue() throws ReservationException {
        if (status != TicketStatus.NEW) {
            throw new ReservationException("Ticket can only move from NEW to ISSUED.");
        }
        status = TicketStatus.ISSUED;
    }

    public void voidTicket() throws ReservationException {
        if (status != TicketStatus.ISSUED) {
            throw new ReservationException("Only an ISSUED ticket can be voided.");
        }
        status = TicketStatus.VOIDED;
    }

    public String reservationId() {
        return reservationId;
    }

    public String ticketCode() {
        return ticketCode;
    }

    public int checkedBags() {
        return checkedBags;
    }

    public TicketStatus status() {
        return status;
    }

    public String toRow() {
        return String.join("|", reservationId, ticketCode, Integer.toString(checkedBags), status.name());
    }

    public static TicketOrder fromRow(String row) {
        String[] parts = row.split("\\|", -1);
        return new TicketOrder(parts[0], parts[1], Integer.parseInt(parts[2]), TicketStatus.valueOf(parts[3]));
    }
}
