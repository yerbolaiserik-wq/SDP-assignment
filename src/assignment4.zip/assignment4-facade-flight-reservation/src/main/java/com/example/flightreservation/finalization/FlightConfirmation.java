package com.example.flightreservation.finalization;

import com.example.flightreservation.domain.ReservationException;

public class FlightConfirmation {
    private final String reservationId;
    private final String confirmationCode;
    private final int loyaltyPoints;
    private final String mealPreference;
    private ConfirmationStatus status;

    public FlightConfirmation(String reservationId, String confirmationCode, int loyaltyPoints, String mealPreference) {
        this(reservationId, confirmationCode, loyaltyPoints, mealPreference, ConfirmationStatus.NEW);
    }

    public FlightConfirmation(String reservationId, String confirmationCode, int loyaltyPoints, String mealPreference, ConfirmationStatus status) {
        this.reservationId = reservationId;
        this.confirmationCode = confirmationCode;
        this.loyaltyPoints = loyaltyPoints;
        this.mealPreference = mealPreference;
        this.status = status;
    }

    public void finalizeConfirmation() throws ReservationException {
        if (status != ConfirmationStatus.NEW) {
            throw new ReservationException("Confirmation can only move from NEW to FINALIZED.");
        }
        status = ConfirmationStatus.FINALIZED;
    }

    public void cancel() throws ReservationException {
        if (status != ConfirmationStatus.FINALIZED) {
            throw new ReservationException("Only a FINALIZED confirmation can be cancelled.");
        }
        status = ConfirmationStatus.CANCELLED;
    }

    public String reservationId() {
        return reservationId;
    }

    public String confirmationCode() {
        return confirmationCode;
    }

    public int loyaltyPoints() {
        return loyaltyPoints;
    }

    public String mealPreference() {
        return mealPreference;
    }

    public ConfirmationStatus status() {
        return status;
    }

    public String toRow() {
        return String.join("|", reservationId, confirmationCode, Integer.toString(loyaltyPoints), mealPreference, status.name());
    }

    public static FlightConfirmation fromRow(String row) {
        String[] parts = row.split("\\|", -1);
        return new FlightConfirmation(parts[0], parts[1], Integer.parseInt(parts[2]), parts[3], ConfirmationStatus.valueOf(parts[4]));
    }
}
