package com.example.flightreservation.reservation;

public enum SeatHoldStatus {
    NEW,
    HELD,
    RELEASED
}
