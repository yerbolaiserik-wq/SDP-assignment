package com.example.flightreservation;

import com.example.flightreservation.facade.FlightReservationFacade;
import com.example.flightreservation.facade.ReservationAdminFacade;
import com.example.flightreservation.domain.ReservationException;
import com.example.flightreservation.domain.ReservationRequest;
import com.example.flightreservation.facade.ReservationResult;

import java.nio.file.Path;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ApplicationServices services = new ApplicationServices(Path.of("data"));
        FlightReservationFacade reservationFacade = services.reservationFacade();
        ReservationAdminFacade adminFacade = services.adminFacade();
        Scanner scanner = new Scanner(System.in);
        try {
            int recovered = adminFacade.recoverIncompleteChains();
            System.out.println("Recovered incomplete persisted chains: " + recovered);
        } catch (ReservationException error) {
            System.err.println("Recovery needs attention: " + error.getMessage());
        }

        while (true) {
            System.out.println();
            System.out.println("Flight Reservation system");
            System.out.println("1. Path reservation");
            System.out.println("2. Force B failure after seat hold");
            System.out.println("3. Force C failure after ticket issue");
            System.out.println("4. Inspect persisted state");
            System.out.println("5. Reset persisted store");
            System.out.println("6. New reservation");
            System.out.println("7. Recover incomplete chains");
            System.out.println("8. Manually compensate a reservation");
            System.out.println("9. Demonstrate A, B, C independently (isolated demo store)");
            System.out.println("0. Exit");
            System.out.print("Choose: ");
            String choice = scanner.nextLine();

            try {
                switch (choice) {
                    case "1" -> runReservation(reservationFacade, new ReservationRequest("Aigerim", "KC-921", "12A", "ECONOMY", 1, "LOY-44", "standard"));
                    case "2" -> runReservation(reservationFacade, new ReservationRequest("FAIL_TICKET", "KC-921", "14C", "ECONOMY", 1, "LOY-44", "standard"));
                    case "3" -> runReservation(reservationFacade, new ReservationRequest("Aigerim", "KC-921", "15D", "PREMIUM", 1, "REJECT", "standard"));
                    case "4" -> System.out.println(adminFacade.inspectState());
                    case "5" -> {
                        services.resetStore();
                        System.out.println("Store reset.");
                    }
                    case "6" -> runReservation(reservationFacade, readRequest(scanner));
                    case "7" -> System.out.println("Recovered: " + adminFacade.recoverIncompleteChains());
                    case "8" -> {
                        System.out.print("Reservation ID: ");
                        adminFacade.compensateFromPersistedState(scanner.nextLine().trim());
                        System.out.println("Compensation completed.");
                    }
                    case "9" -> IndependentSubsystemDemo.run();
                    case "0" -> {
                        return;
                    }
                    default -> System.out.println("Unknown choice.");
                }
            } catch (ReservationException | IllegalArgumentException error) {
                System.out.println("Operation failed: " + error.getMessage());
            }
        }
    }

    private static ReservationRequest readRequest(Scanner scanner) {
        System.out.print("Passenger name: "); String name = scanner.nextLine();
        System.out.print("Flight number: "); String flight = scanner.nextLine();
        System.out.print("Seat number: "); String seat = scanner.nextLine();
        System.out.print("Fare class (ECONOMY/PREMIUM/BUSINESS): "); String fare = scanner.nextLine();
        System.out.print("Checked bags (number): "); int bags = Integer.parseInt(scanner.nextLine().trim());
        System.out.print("Loyalty ID: "); String loyalty = scanner.nextLine();
        System.out.print("Meal preference: "); String meal = scanner.nextLine();
        return new ReservationRequest(name, flight, seat, fare, bags, loyalty, meal);
    }

    private static void runReservation(FlightReservationFacade reservationFacade, ReservationRequest request) throws ReservationException {
        ReservationResult result = reservationFacade.reserveFlight(request);
        System.out.println("Reservation completed:");
        System.out.println("  Reservation: " + result.reservationId());
        System.out.println("  Ticket: " + result.ticketCode());
        System.out.println("  Confirmation: " + result.confirmationCode());
        System.out.println("  Fare: " + result.fare());
    }
}
