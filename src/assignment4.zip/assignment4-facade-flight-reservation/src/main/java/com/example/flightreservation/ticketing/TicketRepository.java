package com.example.flightreservation.ticketing;

import com.example.flightreservation.persistence.CsvFileStore;

import java.util.List;
import java.util.Optional;

public class TicketRepository {
    private static final String FILE_NAME = "tickets.csv";
    private final CsvFileStore store;

    public TicketRepository(CsvFileStore store) {
        this.store = store;
    }

    public void save(TicketOrder ticket) {
        store.upsert(FILE_NAME, ticket.reservationId(), ticket.toRow());
    }

    public Optional<TicketOrder> findByReservationId(String reservationId) {
        return store.findById(FILE_NAME, reservationId).map(TicketOrder::fromRow);
    }

    public List<TicketOrder> findAll() {
        return store.readRows(FILE_NAME).stream().map(TicketOrder::fromRow).toList();
    }
}
