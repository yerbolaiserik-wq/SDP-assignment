Set-Location $PSScriptRoot\..

$sources = Get-ChildItem -Recurse -Filter *.java src\main\java
$javaHome = "$env:USERPROFILE\.jdks\openjdk-27"
$javac = if (Test-Path "$javaHome\bin\javac.exe") { "$javaHome\bin\javac.exe" } else { "javac" }
$java = if (Test-Path "$javaHome\bin\java.exe") { "$javaHome\bin\java.exe" } else { "java" }

if (Test-Path build\classes) {
    Remove-Item -Recurse -Force build\classes
}

New-Item -ItemType Directory -Force build\classes | Out-Null
& $javac -d build\classes $sources.FullName
& $java -cp build\classes com.example.flightreservation.Main
