Set-Location $PSScriptRoot\..

if (Test-Path data) {
    Remove-Item -Recurse -Force data
}

New-Item -ItemType Directory -Force data | Out-Null
Write-Host "Persistent store reset."
