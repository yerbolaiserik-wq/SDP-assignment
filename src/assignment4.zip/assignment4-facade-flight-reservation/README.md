# Assignment 4 Facade Pattern

Topic: Flight Reservation

This project implements a flight reservation system using the Facade pattern over three independent subsystems.

The facade gives the client one simple operation:

```text
reserveFlight()
```

Behind that one call, the system performs a three-stage chain:

```text
A. Seat reservation and fare calculation
B. E-ticket issuing and baggage validation
C. Loyalty points and meal preference finalization
```

## Subsystems

### Subsystem A Reservation

Classes:

- `SeatHold`
- `SeatHoldStatus`
- `SeatAvailabilityPolicy`
- `FareCalculator`
- `SeatMapRepository`
- `SeatReservationService`

This subsystem holds a seat and calculates the fare. It persists seat holds in `data/seat-holds.csv`.

### Subsystem B Ticketing

Classes:

- `TicketOrder`
- `TicketStatus`
- `BaggageRulesEngine`
- `TicketRepository`
- `ETicketIssuer`

This subsystem validates baggage and issues an e-ticket. It persists tickets in `data/tickets.csv`.

### Subsystem C Finalization

Classes:

- `FlightConfirmation`
- `ConfirmationStatus`
- `LoyaltyProgram`
- `MealPreferenceService`
- `ConfirmationRepository`
- `ReservationFinalizer`

This subsystem awards loyalty points, stores meal preferences, and creates the final confirmation. It persists confirmations in `data/confirmations.csv`.

## Facades

### FlightReservationFacade

This is the main client facade. It performs the whole chain:

```text
SeatReservationService -> ETicketIssuer -> ReservationFinalizer
```

It also compensates previous steps when a later step fails.

### ReservationAdminFacade

This is the administrative facade. It allows the user to inspect persisted state and manually compensate a reservation from the chain status saved on disk.

## Compensation Scenarios

### B fails after A commits

Example trigger:

```text
passengerName = FAIL_TICKET
```

Result:

```text
A committed seat hold
B failed ticket issuing
Facade releases seat hold
Chain status becomes COMPENSATED
```

### C fails after A and B commit

Example trigger:

```text
loyaltyId = REJECT
```

Result:

```text
A committed seat hold
B issued ticket
C failed loyalty finalization
Facade voids ticket
Facade releases seat
Chain status becomes COMPENSATED
```

## Persistence

The project uses plain CSV files as durable storage.

The persisted files are:

```text
data/seat-holds.csv
data/tickets.csv
data/confirmations.csv
data/chain-progress.csv
```

If the application is stopped and restarted, the state remains on disk.

## Run the Demo

From the project folder:

```powershell
.\scripts\run.ps1
```

Reset the persistent store:

```powershell
.\scripts\reset-store.ps1
```

The CLI menu lets the examiner:

- run the happy path
- force the B failure
- force the C failure
- inspect persisted state
- reset the store

## Run Tests

If Maven is installed:

```powershell
mvn test
```

The Maven build also includes JaCoCo:

```powershell
mvn test jacoco:report
```

## Principle of Least Knowledge

Without the facade, client code would need to know too many classes:

```java
SeatReservationService seats = ...
ETicketIssuer tickets = ...
ReservationFinalizer finalizer = ...
ChainProgressRepository progress = ...

SeatHold hold = seats.reserveSeat(request);
progress.save(new ReservationProgress(hold.reservationId(), ChainStatus.PENDING_TICKET, "Seat held"));
TicketOrder ticket = tickets.issueTicket(hold.reservationId(), request);
progress.save(new ReservationProgress(hold.reservationId(), ChainStatus.PENDING_FINALIZATION, "Ticket issued"));
FlightConfirmation confirmation = finalizer.finalizeReservation(hold.reservationId(), ticket.ticketCode(), hold.fare(), request);
```

With the facade, the client only talks to one class:

```java
ReservationResult result = flightReservationFacade.reserveFlight(request);
```

This follows the Principle of Least Knowledge because the client does not need to understand the internal subsystem sequence.

## Facade vs Adapter Reflection

This problem needs a Facade, not an Adapter, because the goal is not to make one incompatible class match another interface. The goal is to hide a complicated workflow involving three independent subsystems. Seat reservation, ticket issuing, and final confirmation are all separate processes with their own state and persistence. The client should not coordinate them directly or know how compensation works. The facade provides one simple operation while internally managing sequencing, persistence, failure handling, and rollback. An Adapter would be useful if only one old class had the wrong interface. Here, the problem is broader: the client needs a simple front door to a multi-step subsystem chain.

## UML

See:

```text
docs/uml-class-diagram.puml
```


## Updates to the uploaded project

- CLI option 6 accepts interactive booking input; options 7–8 handle persisted recovery and manual compensation.
- Startup reconciliation compensates pending chains using persisted confirmation, ticket, then seat statuses.
- Cross-subsystem method parameters are IDs/scalars rather than foreign subsystem entity types.
- Duplicate active seat holds are rejected; released seats are reusable.
- Run `mvn clean verify` locally to obtain the JaCoCo coverage report at `target/site/jacoco/index.html`. At least 80% coverage must be **measured**, not assumed.
- Note: recovery compensates incomplete chains rather than resuming ticket issuance.


## Independent subsystem defense demo

Run `com.example.flightreservation.IndependentSubsystemDemo` directly, or select menu option **9**.
It creates a separate temporary CSV store and independently invokes each subsystem (A, B, C) without the facades or another subsystem's entity types. Each prints its persisted status.

## Shared request / exception types

`domain.ReservationRequest` and `domain.ReservationException` are shared input/error types, not subsystem entities. Neither B nor C imports A, and neither A nor B imports C. `ReservationRequest` is passed to each subsystem without passing another subsystem's entity.

## Recovery policy and limitations

On restart, `ReservationAdminFacade.recoverIncompleteChains()` reads on-disk chain progress and committed entity rows. Incomplete chains are **compensated** (not resumed), in the order C -> B -> A where present. Compensation is idempotent for completed rollbacks. A process crash between saving the first seat and saving the initial progress entry can still orphan a seat; this project does not claim crash-atomic CSV transactions. A full production implementation would add write-ahead journaling / stronger atomicity.

## Verify locally (requires Java 17+ and Maven)

```sh
mvn clean verify
```

The coverage HTML report is at `target/site/jacoco/index.html`. The assignment requires **at least 80% line coverage** for the three subsystems and facades. A report must be generated and checked before claiming this is met.

## UML

`docs/uml-class-diagram.puml` is the class-diagram source. Render it into `docs/uml-class-diagram.svg` using PlantUML. If the source changes again, regenerate the SVG; a static diagram from a previous revision is not guaranteed to match.
