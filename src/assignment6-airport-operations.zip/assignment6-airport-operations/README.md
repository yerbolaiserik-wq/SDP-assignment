# Assignment 6 Airport Operations

## Start here

The program has two main ideas:

1. **Observer:** a flight or gate update automatically notifies the listeners.
2. **Visitor:** a report walks through the airport objects to calculate a result.

Read `Main.java` first. Its numbered steps build the airport, create sources and listeners, subscribe the listeners, and publish three updates. Helper methods handle the sample data and printing. Read `docs/EXPLANATION.md` next for a short walkthrough.

The visitor calculations use ordinary `for` loops, without Stream API pipelines. Each `visit` method is written out separately. The required generic interfaces and thread-safe listener code remain, because they are part of the assignment.

## Open and run

Open this folder's `pom.xml` in IntelliJ as a Maven project and let Maven import it. Choose a JDK 17 or newer. Right-click `com.example.airport.Main` and run `main()`.

On Windows without Maven on PATH:

```powershell
.\run.ps1
.\run.ps1 -Threads 4
.\run.ps1 -Json
.\test.ps1 -Offline
```

With Maven:

```text
mvn test
mvn package
java -jar target/assignment6-airport-operations-1.0.0.jar 3
java -jar target/assignment6-airport-operations-1.0.0.jar 3 --json
```

The script compiles using `--release 17`. The only application dependencies are Java standard classes; the only test dependency is JUnit 5. The Maven plugins are build tools.

## Observer decisions

`Subject<E>` and `Observer<E>` are our own generic interfaces. Two independent `EventSource<AirportEvent>` objects represent the flight feed and the gate feed. Every immutable event has an event type, source, location ID, message and value. Listeners subscribe to specific types.

Five domain listeners are DepartureBoard, PassengerNotifier, GateManager, BaggageSystem and TerminalAggregator. InspectionService and EventLog provide additional integration and recording. TerminalAggregator is both a listener and a subject: it counts updates per gate and publishes a new TERMINAL_SUMMARY event.

We use push delivery. An immutable event already carries the data needed by listeners, so they do not need to query a mutable source that another thread might change.

Subscriptions use CopyOnWriteArrayList with duplicate prevention. A publish call captures one immutable array snapshot. A listener may join or leave from its callback without changing the current iteration. A removed listener can still receive an event from an already captured snapshot; the next snapshot will exclude it. Self-unsubscription does not guarantee exactly one call when publications are already in flight on multiple threads. Updates do not lock the entire subject.

Delivery is synchronous within each producer thread. Listener exceptions are collected, other listeners still receive the event, and the failure propagates to the producer. We do not claim persistent event delivery across process crashes.

## Visitor decisions

The immutable Composite tree has four levels: AirportArea (airport), AirportArea (terminal), Gate, then leaves. AirportArea and Gate are the two container types. The four leaf types are Flight, Lounge, Shop and ParkingStand. Elements contain data, validation and `accept` only.

Visitor<R> has a typed visit overload per element. An element's `accept` calls `visitor.visit(this)`. This is double dispatch: first the runtime element chooses its accept implementation, then that method selects the visit overload for its concrete type.

Visitors own traversal. This lets each operation decide whether to recurse and how to combine results, while elements remain independent of business operations.

The four initial visitors are RevenueVisitor (long cents), InventoryVisitor (state accumulated across the entire walk), FilterVisitor (matching elements), and JsonExportVisitor (hand-written nested JSON with escaped strings). PassengerLoadVisitor is a fifth visitor added in its own commit. InspectionService receives its stateless RevenueVisitor through constructor injection; it is safe to share. Mutable InventoryVisitor instances belong to one traversal and are not shared between threads.

## Integration and concurrency

Flight/gate event -> InspectionService -> RevenueVisitor on the referenced gate only -> INSPECTION_REPORT event -> EventLog. The airport tree is an immutable snapshot; feed updates trigger reports without mutating its revenue or passenger fields.

Main is the single composition root. It constructs the tree, listeners, sources and ExecutorService and wires all dependencies. Services use constructor injection; no lazy business initialization or service locator.

There are three producer tasks on a fixed thread pool. The pool size is configurable (default 3). ProducerRunner waits for every submitted task, propagates failures and closes the executor gracefully. On interruption or a shutdown timeout the run fails explicitly rather than reporting success. Maps, queues and counters used by callbacks are concurrent; tree children are immutable copies. Console output occurs after producers finish. Parallel notification order may vary; counts are stable. Unbounded in-memory queues are intentional for this small demo; a long-running service would need retention/backpressure.

## Documentation and output

- `docs/uml.puml`: UML class diagram in PlantUML format.
- `docs/uml.md`: the same architecture as a GitHub-renderable Mermaid class diagram.
- `docs/REPORT.md`: report draft for LMS; review it and add your student details and GitHub link before submitting.
- `docs/EXPLANATION.md`: beginner explanation, method guide, output meanings and defense questions.

The demo has fixed sample data and terminates automatically. Default output has three sections: listener updates, gate revenue after each update, and the whole-airport report. It prints names and individual counts instead of raw Java records or maps. The long JSON export is optional: use `-Json` with the script or `--json` with Main.

Expected results with any positive pool size: 2 passenger notifications, 2 baggage updates, 2 updates for A1 and 1 for B1, 6 derived events internally, total revenue $19,000.00 and 200 people. A1 inspection returns $11,000.00 and B1 returns $8,000.00. A1 appears twice in the gate reports because two updates refer to that gate. Parallel event order may vary. These are simulated notices, not actual SMS or airport-system calls.

Open `pom.xml` as the project, rather than importing `src/main` as a separate module. Let IntelliJ finish Maven import before running Main. The `target` or `build` folders contain generated bytecode and can be recreated; source code stays under `src/main/java`.

Verification uses Java 27 with `--release 17`, targeting Java 17 APIs and bytecode. No Java 17 runtime is installed locally, so execution on that exact runtime has not been separately tested.

## Trade-off proof 1 new visitor

Commit subject: `Add passenger load visitor without changing any elements`.

Files changed (paths relative to this project):

- `src/main/java/com/example/airport/visitor/PassengerLoadVisitor.java`
- `src/test/java/com/example/airport/PassengerLoadVisitorTest.java`
- `README.md`

No file in `tree/` or the Visitor interface changes. The new operation counts passengers on flights and guests in lounges, ignoring shops. This is a snapshot headcount; the demo treats those groups as disjoint. The cost is one new implementation and its tests, so Visitor works well when new operations are common but element types are stable.

## Trade-off proof 2 new element

Commit subject: `Add parking stand element and update every visitor`.

Files changed (paths relative to this project):

- `src/main/java/com/example/airport/tree/ParkingStand.java`
- `src/main/java/com/example/airport/visitor/Visitor.java`
- `src/main/java/com/example/airport/visitor/RevenueVisitor.java`
- `src/main/java/com/example/airport/visitor/InventoryVisitor.java`
- `src/main/java/com/example/airport/visitor/FilterVisitor.java`
- `src/main/java/com/example/airport/visitor/JsonExportVisitor.java`
- `src/main/java/com/example/airport/visitor/PassengerLoadVisitor.java`
- `src/main/java/com/example/airport/Main.java`
- `src/test/java/com/example/airport/ParkingStandTest.java`
- `README.md`

ParkingStand adds an aircraft parking fee. Revenue includes its fee; inventory counts it; filtering and export include it; passenger load returns zero. Adding a leaf requires changing the Visitor interface and all five concrete visitors. Compilation exposes forgotten overloads. If element types changed frequently, this widespread editing cost could make Visitor unsuitable.

Run `git log --oneline` and `git show --stat <commit>` to inspect both proofs. Neither changes a historical date.
