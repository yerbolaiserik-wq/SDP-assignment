param([switch]$Offline)
$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    $jdk = Join-Path $env:USERPROFILE '.jdks\openjdk-27'
    if (Test-Path "$jdk\bin\java.exe") { $env:JAVA_HOME = $jdk }
    $maven = Get-Command mvn.cmd -ErrorAction SilentlyContinue
    if ($maven) { $mavenPath = $maven.Source }
    else {
        $bundled = Get-ChildItem 'C:\Program Files\JetBrains\*\plugins\maven\lib\maven3\bin\mvn.cmd' -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $bundled) { throw 'Maven not found. Run the tests using IntelliJ Maven, or install Maven.' }
        $mavenPath = $bundled.FullName
    }
    $arguments = @('test')
    if ($Offline) { $arguments += '-o' }
    & $mavenPath @arguments
    if ($LASTEXITCODE -ne 0) { throw 'Tests failed.' }
} finally { Pop-Location }
