# Airport Operations Observer and Visitor Report

## Project purpose

This project implements Assignment 6, variant 8, Airport operations, using Java 17-compatible code and JUnit 5. It simulates airport events and demonstrates how Observer and Visitor can cooperate. It uses no external application libraries. The project does not connect to a real airport, SMS service or financial system.

## Observer design

Two live data sources publish flight status and gate status events. Subject<E> and Observer<E> are generic interfaces implemented by the project. AirportEvent is an immutable typed record. Subscribers register per EventType and can join or leave at runtime, including inside callbacks.

DepartureBoard, PassengerNotifier, GateManager, BaggageSystem and TerminalAggregator are the five main listeners. TerminalAggregator is also a subject: it counts updates by gate and republishes immutable summary events. EventLog records derived events. Push delivery avoids querying a mutable source after notification.

The listener registry uses CopyOnWriteArrayList. Publication takes a snapshot, so subscription changes do not invalidate an active iteration. Unsubscription takes effect for subsequent snapshots; already in-flight callbacks may finish. Duplicate subscriptions are prevented. Listener errors are collected and propagated after all listeners have been attempted.

## Visitor and Composite design

AirportArea and Gate are containers. The tree is AirportArea airport -> AirportArea terminal -> Gate -> leaves, giving four levels. The four leaf types are Flight, Lounge, Shop and ParkingStand. Element records only hold data, validate it, and dispatch through accept.

Visitor<R> supports double dispatch with one typed visit overload per concrete element. RevenueVisitor calculates numeric revenue, InventoryVisitor accumulates counts over a whole traversal, FilterVisitor returns matching elements, JsonExportVisitor produces correctly nested escaped JSON, and PassengerLoadVisitor calculates people in the snapshot. Visitors perform traversal so operation-specific recursion stays outside element classes.

Revenue uses integer cents. The sample A1 total is 1000000 + 50000 + 30000 + 20000 = 1100000 cents. B1 contributes 800000 cents, giving 1900000 cents ($19000.00) overall. People total 100 + 80 + 20 = 200.

## Integration

InspectionService observes source events, finds the affected gate using subtreeId, invokes the injected RevenueVisitor only on that subtree, then publishes INSPECTION_REPORT to the report source. It never visits an unrelated gate. Separate event types and source wiring prevent feedback loops. Aggregate events also ignore incoming aggregate types.

## Clean Code and concurrency

Main is the composition root and supplies dependencies through constructors. Business services do not lazily create dependencies. Immutable event records and tree nodes are safe to share. Callback state uses concurrent maps, queues and counters. Stateful inventory visitors are local to one walk; the injected revenue visitor is stateless.

At least three producer tasks execute on an ExecutorService. Pool size is configurable. ProducerRunner waits for each submitted future, propagates errors and shuts down the executor gracefully. An interrupted or timed-out shutdown fails explicitly. No global subject lock serializes publication. Cross-thread ordering is not promised.

## Trade-off evidence

Commit 5876354 adds PassengerLoadVisitor and its tests without changing any element or the Visitor interface. Commit dc427ad adds ParkingStand and updates the Visitor interface plus all five visitors. README lists the exact files for each commit. The first change shows the low cost of adding an operation; the second shows the broader cost of changing the element family.

## Verification

The completed suite has 36 JUnit tests. It covers runtime subscription changes, concurrent unsubscription, listener failures, aggregation, scoped observer-to-visitor integration, immutable containers, hand-calculated totals, JSON escaping/nesting, the additional visitor and element, executor shutdown, readable default output, and optional JSON output.

The required stress test uses four producer threads with 1000 events each. It checks exactly 4000 original events, 4000 derived summary events, 4000 unique aggregate values and executor termination. Hand-calculated visitor tests use small trees with explicit expected answers.

Tests and compilation run locally with JDK 27 targeting release 17. Java 17 runtime execution has not been separately tested. Demo runs with pool sizes 1, 2 and 4 check that totals remain the same despite possible ordering differences.

