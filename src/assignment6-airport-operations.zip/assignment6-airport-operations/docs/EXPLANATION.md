# Simple project walkthrough

## Start with Main.java

The program follows four steps:

1. Build the airport: an airport contains a terminal, the terminal contains gates, and gates contain flights, a lounge, a shop and a parking stand.
2. Create sources and listeners. A source sends updates; a listener reacts to updates.
3. Subscribe the listeners to the event types they need.
4. Publish three updates using worker threads, wait for them to finish, then print the reports.

The numbered comments in Main match these steps. createGateA and createGateB build the sample data. runUpdates starts the three producer tasks. printUpdates and printVisitorResults handle the readable output.

## Observer means react to an update

A flight source publishes "KC101 is boarding at A1". Its subscribed listeners receive the same event automatically.

- DepartureBoard remembers the message.
- PassengerNotifier stores a passenger notice.
- BaggageSystem counts the flight update.
- TerminalAggregator counts updates per gate, then publishes a summary event.
- InspectionService calculates revenue for the affected gate, then publishes a report event.

GateManager listens to the separate gate source. EventLog stores the summaries and reports.

The three important methods are subscribe (start listening), publish (send an update), and onEvent (react to the update). unsubscribe stops listening to future publication snapshots.

AirportEvent is an immutable record: its values cannot be changed after it is created. EventType says what kind of update it is. The source, gate ID and message explain where the event came from and what happened. value holds a count for summaries or money in cents for revenue reports.

## Visitor means perform an operation on airport objects

Each airport object has an accept method. It passes itself to a visitor:

```java
public <R> R accept(Visitor<R> visitor) {
    return visitor.visit(this);
}
```

For a Flight, this calls visit(Flight). For a Gate, it calls visit(Gate). This is double dispatch: Java chooses the element's accept implementation, then the concrete visit overload.

A container visit uses a loop to visit its children. A leaf visit returns its own value.

| Visitor | What it does |
| --- | --- |
| RevenueVisitor | Adds the money from flights, lounges, shops and parking stands. |
| PassengerLoadVisitor | Adds flight passengers and lounge guests. |
| InventoryVisitor | Counts how many objects of each type it visited. |
| FilterVisitor | Finds elements that satisfy a condition, such as flights with at least 90 passengers. |
| JsonExportVisitor | Converts the tree into correctly nested JSON text. |

The visitor code uses ordinary for loops. For example, revenue starts at zero and adds each child's result. Element records hold data and accept visitors; the calculations stay inside the visitors.

## How the patterns work together

Flight or gate update -> InspectionService -> RevenueVisitor on that gate -> report event -> EventLog.

A1 and B1 are different subtrees. An update for A1 does not calculate B1's revenue. The data is a fixed sample snapshot, so a delay notice does not change passenger numbers or revenue.

## Understand the output

- Two flight notices are shown: KC101 is boarding and KC202 is delayed.
- Gate A1 is open.
- Baggage staff receive 2 flight updates.
- A1 has 2 updates: one flight update and one gate update. B1 has 1.
- A1 revenue is $11,000: $10,000 flight + $500 lounge + $300 shop + $200 aircraft parking.
- B1 revenue is $8,000. The whole airport earns $19,000.
- People total 200: 100 on KC101 + 80 on KC202 + 20 lounge guests, treated as separate groups.
- KC101 is the only flight with at least 90 passengers.
- The object counts list 2 areas (airport and terminal), 2 gates, 2 flights, 1 lounge, 1 shop and 1 parking stand.

A1 appears twice in the gate reports because two different updates trigger its revenue visitor. Parallel updates can appear in a different order each run.

JSON is hidden by default to keep the output short. To see the JSON export, run Main with --json or use .\run.ps1 -Json.

## The required advanced parts

Subject<E> and Observer<E> are generic interfaces: E stands for the event type. Visitor<R> is also generic: R stands for the result type, such as Long for revenue or String for JSON. InventoryVisitor uses Void because it saves counts in its own map instead of returning a value from each visit.

ExecutorService manages worker threads. ProducerRunner submits the tasks, waits for every Future, then shuts the executor down. The default is 3 worker threads; use .\run.ps1 -Threads 4 to change it.

CopyOnWriteArrayList keeps listener iteration safe when subscriptions change. An event already being published may still reach an unsubscribed listener; later publication snapshots exclude it. Concurrent maps, queues and counters keep listener data safe across threads.

