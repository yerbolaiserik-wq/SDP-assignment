package com.example.airport;

import com.example.airport.observer.*;
import com.example.airport.tree.*;
import com.example.airport.visitor.RevenueVisitor;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import static org.junit.jupiter.api.Assertions.*;

class IntegrationTest {
    @Test void eventRunsVisitorOnRelatedGateOnlyAndPublishesReport() {
        Gate gateA = new Gate("A1", "Gate A1", List.of(new Shop("S1", "Coffee", 500)));
        Gate gateB = new Gate("B1", "Gate B1", List.of(new Shop("S2", "Gifts", 900)));
        EventSource<AirportEvent> source = new EventSource<>();
        EventSource<AirportEvent> reports = new EventSource<>();
        EventLog log = new EventLog();
        InspectionService inspection = new InspectionService(Map.of("A1", gateA, "B1", gateB), reports,
                new RevenueVisitor());
        source.subscribe(EventType.GATE_STATUS, inspection);
        reports.subscribe(EventType.INSPECTION_REPORT, log);
        source.publish(new AirportEvent(EventType.GATE_STATUS, "Gates", "A1", "Open", 1));
        assertEquals(1, log.events().size());
        assertEquals("A1", log.events().get(0).subtreeId());
        assertEquals(500, log.events().get(0).value());
        assertEquals(EventType.INSPECTION_REPORT, log.events().get(0).type());
    }

    @Test void unknownGateIsReportedAsFailureInsteadOfInspectingWholeAirport() {
        InspectionService service = new InspectionService(Map.of(), new EventSource<>(), new RevenueVisitor());
        assertThrows(IllegalArgumentException.class, () -> service.onEvent(
                new AirportEvent(EventType.GATE_STATUS, "Gates", "missing", "Open", 1)));
    }

    @Test @Timeout(10) void producerFailureStillAllowsOtherProducerToFinishAndClosesPool() throws Exception {
        var pool = Executors.newFixedThreadPool(3);
        EventLog log = new EventLog();
        try (ProducerRunner runner = new ProducerRunner(pool)) {
            assertThrows(IllegalStateException.class, () -> runner.runAll(List.of(
                    () -> { throw new IllegalArgumentException("source failed"); },
                    () -> log.onEvent(new AirportEvent(EventType.GATE_STATUS, "Gates", "A1", "Open", 1)))));
        }
        assertEquals(1, log.events().size());
        assertTrue(pool.isTerminated());
    }

    @Test @Timeout(10) void twoSourcesNotifyAllFiveAirportListeners() throws Exception {
        EventSource<AirportEvent> flights = new EventSource<>();
        EventSource<AirportEvent> gates = new EventSource<>();
        DepartureBoard board = new DepartureBoard();
        PassengerNotifier passengers = new PassengerNotifier();
        GateManager manager = new GateManager();
        BaggageSystem baggage = new BaggageSystem();
        TerminalAggregator aggregator = new TerminalAggregator();
        flights.subscribe(EventType.FLIGHT_STATUS, board);
        flights.subscribe(EventType.FLIGHT_STATUS, passengers);
        flights.subscribe(EventType.FLIGHT_STATUS, baggage);
        flights.subscribe(EventType.FLIGHT_STATUS, aggregator);
        gates.subscribe(EventType.GATE_STATUS, manager);
        gates.subscribe(EventType.GATE_STATUS, aggregator);
        try (ProducerRunner runner = new ProducerRunner(Executors.newFixedThreadPool(3))) {
            runner.runAll(List.of(
                    () -> flights.publish(new AirportEvent(EventType.FLIGHT_STATUS, "Flights", "A1", "Boarding", 1)),
                    () -> flights.publish(new AirportEvent(EventType.FLIGHT_STATUS, "Flights", "B1", "Delayed", 1)),
                    () -> gates.publish(new AirportEvent(EventType.GATE_STATUS, "Gates", "A1", "Open", 1))));
        }
        assertEquals(2, board.messages().size());
        assertEquals(2, passengers.notifications().size());
        assertEquals(Map.of("A1", "Open"), manager.gates());
        assertEquals(2, baggage.updates());
        assertEquals(2, aggregator.count("A1"));
        assertEquals(1, aggregator.count("B1"));
    }
}
