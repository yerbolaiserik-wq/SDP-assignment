package com.example.airport;

import com.example.airport.tree.*;
import com.example.airport.visitor.PassengerLoadVisitor;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;

class PassengerLoadVisitorTest {
    @Test void newOperationCalculatesPeopleWithoutChangingElements() {
        Gate gate = new Gate("A1", "Gate A1", List.of(new Flight("F1", "Flight", 100, 50000),
                new Lounge("L1", "Lounge", 20, 2000), new Shop("S1", "Coffee", 3000)));
        AirportArea terminal = new AirportArea("T1", "Terminal", List.of(gate));
        assertEquals(120, terminal.accept(new PassengerLoadVisitor()));
    }

    @Test void emptyGateHasNoPeople() {
        assertEquals(0, new Gate("G", "Gate", List.of()).accept(new PassengerLoadVisitor()));
    }
}
