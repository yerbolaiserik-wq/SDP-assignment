package com.example.airport;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;

@Timeout(10)
class MainTest {
    private String runDemo(String... arguments) throws InterruptedException {
        PrintStream originalOutput = System.out;
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try (PrintStream captured = new PrintStream(output, true, StandardCharsets.UTF_8)) {
            System.setOut(captured);
            Main.main(arguments);
        } finally {
            System.setOut(originalOutput);
        }
        return output.toString(StandardCharsets.UTF_8);
    }

    @Test void defaultOutputShowsPlainReportsWithoutJsonOrJavaObjects() throws Exception {
        String output = runDemo();
        assertTrue(output.contains("Total revenue: $19,000.00"));
        assertTrue(output.contains("Passengers and lounge guests: 200"));
        assertTrue(output.contains("  Flight KC101"));
        assertTrue(output.contains("  Parking stands: 1"));
        assertFalse(output.contains("{"));
        assertFalse(output.contains("Flight[id="));
    }

    @Test void jsonCanBeRequestedWithAConfiguredThreadCount() throws Exception {
        String output = runDemo("4", "--json");
        assertTrue(output.contains("Worker threads: 4"));
        assertTrue(output.contains("4. JSON export"));
        assertTrue(output.contains("\"children\":["));
        assertTrue(output.contains("\"type\":\"parkingStand\""));
    }

    @Test void zeroThreadsIsRejectedBeforeStartingThePool() {
        assertThrows(IllegalArgumentException.class, () -> Main.main(new String[]{"0"}));
    }
}
