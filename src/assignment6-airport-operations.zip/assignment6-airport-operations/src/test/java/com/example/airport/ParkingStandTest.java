package com.example.airport;

import com.example.airport.tree.*;
import com.example.airport.visitor.*;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class ParkingStandTest {
    @Test void newElementParticipatesInRevenueButNotPassengerLoad() {
        Gate gate = new Gate("G", "Gate", List.of(new Flight("F", "Flight", 100, 10000),
                new ParkingStand("P", "Stand", 2000)));
        assertEquals(12000L, gate.accept(new RevenueVisitor()));
        assertEquals(100, gate.accept(new PassengerLoadVisitor()));
    }

    @Test void statefulVisitorCountsNewElement() {
        InventoryVisitor visitor = new InventoryVisitor();
        new ParkingStand("P", "Stand", 2000).accept(visitor);
        assertEquals(Map.of("Parking stands", 1), visitor.counts());
    }

    @Test void filterAndExportSupportNewElement() {
        ParkingStand stand = new ParkingStand("P", "Stand", 2000);
        assertEquals(List.of(stand), stand.accept(new FilterVisitor(element -> element instanceof ParkingStand)));
        assertEquals("{\"type\":\"parkingStand\",\"id\":\"P\",\"name\":\"Stand\",\"feeCents\":2000}",
                stand.accept(new JsonExportVisitor()));
    }

    @Test void parkingFeeMustNotBeNegative() {
        assertThrows(IllegalArgumentException.class, () -> new ParkingStand("P", "Stand", -1));
    }
}
