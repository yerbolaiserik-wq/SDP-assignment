package com.example.airport;

import com.example.airport.observer.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import static org.junit.jupiter.api.Assertions.*;

class ObserverTest {
    private AirportEvent flightEvent() {
        return new AirportEvent(EventType.FLIGHT_STATUS, "Flight feed", "A1", "Boarding", 1);
    }

    @Test void sendsOnlySubscribedEventTypes() {
        EventSource<AirportEvent> source = new EventSource<>();
        EventLog log = new EventLog();
        source.subscribe(EventType.GATE_STATUS, log);
        source.publish(flightEvent());
        assertTrue(log.events().isEmpty());
    }

    @Test void deliversOriginalImmutableEvent() {
        EventSource<AirportEvent> source = new EventSource<>();
        EventLog log = new EventLog();
        source.subscribe(EventType.FLIGHT_STATUS, log);
        AirportEvent event = flightEvent();
        source.publish(event);
        assertSame(event, log.events().get(0));
    }

    @Test void duplicateSubscriptionDeliversOnce() {
        EventSource<AirportEvent> source = new EventSource<>();
        EventLog log = new EventLog();
        source.subscribe(EventType.FLIGHT_STATUS, log);
        source.subscribe(EventType.FLIGHT_STATUS, log);
        source.publish(flightEvent());
        assertEquals(1, log.events().size());
    }

    @Test void unsubscribeStopsLaterDelivery() {
        EventSource<AirportEvent> source = new EventSource<>();
        EventLog log = new EventLog();
        source.subscribe(EventType.FLIGHT_STATUS, log);
        source.publish(flightEvent());
        source.unsubscribe(EventType.FLIGHT_STATUS, log);
        source.publish(flightEvent());
        assertEquals(1, log.events().size());
    }

    @Test void listenerCanUnsubscribeInsideCallback() {
        EventSource<AirportEvent> source = new EventSource<>();
        AtomicInteger calls = new AtomicInteger();
        com.example.airport.observer.Observer<AirportEvent> once = new com.example.airport.observer.Observer<>() {
            public void onEvent(AirportEvent event) {
                calls.incrementAndGet();
                source.unsubscribe(EventType.FLIGHT_STATUS, this);
            }
        };
        source.subscribe(EventType.FLIGHT_STATUS, once);
        source.publish(flightEvent());
        source.publish(flightEvent());
        assertEquals(1, calls.get());
    }

    @Test void newListenerJoinsNextSnapshot() {
        EventSource<AirportEvent> source = new EventSource<>();
        EventLog late = new EventLog();
        source.subscribe(EventType.FLIGHT_STATUS, event -> source.subscribe(EventType.FLIGHT_STATUS, late));
        source.publish(flightEvent());
        assertTrue(late.events().isEmpty());
        source.publish(flightEvent());
        assertEquals(1, late.events().size());
    }

    @Test void failingListenerDoesNotSkipOtherListeners() {
        EventSource<AirportEvent> source = new EventSource<>();
        EventLog log = new EventLog();
        source.subscribe(EventType.FLIGHT_STATUS, event -> { throw new IllegalArgumentException("failed"); });
        source.subscribe(EventType.FLIGHT_STATUS, log);
        RuntimeException error = assertThrows(RuntimeException.class, () -> source.publish(flightEvent()));
        assertEquals(1, error.getSuppressed().length);
        assertEquals(1, log.events().size());
    }

    @Test void sourceCanHaveNoListeners() {
        assertDoesNotThrow(() -> new EventSource<AirportEvent>().publish(flightEvent()));
    }

    @Test void aggregateIsRepublishedAsNewEvent() {
        TerminalAggregator aggregator = new TerminalAggregator();
        EventLog log = new EventLog();
        aggregator.subscribe(EventType.TERMINAL_SUMMARY, log);
        aggregator.onEvent(flightEvent());
        aggregator.onEvent(flightEvent());
        assertEquals(List.of(1L, 2L), log.events().stream().map(AirportEvent::value).toList());
        assertEquals(2, aggregator.count("A1"));
    }

    @Test void aggregatorIgnoresItsOwnEventType() {
        TerminalAggregator aggregator = new TerminalAggregator();
        aggregator.onEvent(new AirportEvent(EventType.TERMINAL_SUMMARY, "test", "A1", "summary", 1));
        assertEquals(0, aggregator.count("A1"));
    }

    @Test @Timeout(10) void unsubscribeAllowsInFlightSnapshotButStopsNextPublication() throws Exception {
        EventSource<AirportEvent> source = new EventSource<>();
        CountDownLatch entered = new CountDownLatch(1);
        CountDownLatch release = new CountDownLatch(1);
        EventLog log = new EventLog();
        source.subscribe(EventType.FLIGHT_STATUS, event -> {
            entered.countDown();
            try {
                if (!release.await(3, TimeUnit.SECONDS)) { throw new IllegalStateException("Timed out"); }
            } catch (InterruptedException error) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException(error);
            }
        });
        source.subscribe(EventType.FLIGHT_STATUS, log);
        ExecutorService pool = Executors.newFixedThreadPool(2);
        try {
            Future<?> publishing = pool.submit(() -> source.publish(flightEvent()));
            assertTrue(entered.await(3, TimeUnit.SECONDS));
            pool.submit(() -> source.unsubscribe(EventType.FLIGHT_STATUS, log)).get(3, TimeUnit.SECONDS);
            release.countDown();
            publishing.get(3, TimeUnit.SECONDS);
            source.publish(flightEvent());
            assertEquals(1, log.events().size());
        } finally {
            release.countDown();
            pool.shutdownNow();
            assertTrue(pool.awaitTermination(3, TimeUnit.SECONDS));
        }
    }

    @Test @Timeout(15) void fourThreadsPublishExactlyFourThousandEvents() throws Exception {
        EventSource<AirportEvent> source = new EventSource<>();
        EventLog log = new EventLog();
        TerminalAggregator aggregator = new TerminalAggregator();
        EventLog summaries = new EventLog();
        source.subscribe(EventType.FLIGHT_STATUS, log);
        source.subscribe(EventType.FLIGHT_STATUS, aggregator);
        aggregator.subscribe(EventType.TERMINAL_SUMMARY, summaries);
        ExecutorService pool = Executors.newFixedThreadPool(4);
        Runnable producer = () -> { for (int i = 0; i < 1000; i++) { source.publish(flightEvent()); } };
        try (ProducerRunner runner = new ProducerRunner(pool)) {
            runner.runAll(List.of(producer, producer, producer, producer));
        }
        assertEquals(4000, log.events().size());
        assertEquals(4000, aggregator.count("A1"));
        assertEquals(4000, summaries.events().size());
        assertEquals(4000, summaries.events().stream().map(AirportEvent::value).distinct().count());
        assertTrue(pool.isTerminated());
    }

    @Test void eventRejectsMissingType() {
        assertThrows(NullPointerException.class, () -> new AirportEvent(null, "feed", "A1", "test", 1));
    }
}
