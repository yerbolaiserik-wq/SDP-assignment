package com.example.airport;

import com.example.airport.tree.*;
import com.example.airport.visitor.*;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class VisitorTest {
    private AirportArea sample() {
        Gate gateA = new Gate("A1", "Gate A1", List.of(new Flight("F1", "Flight", 100, 10000),
                new Lounge("L1", "Lounge", 20, 2000), new Shop("S1", "Shop", 3000)));
        Gate gateB = new Gate("B1", "Gate B1", List.of(new Flight("F2", "Flight 2", 80, 8000)));
        AirportArea terminal = new AirportArea("terminal", "Terminal", List.of(gateA, gateB));
        return new AirportArea("airport", "Airport", List.of(terminal));
    }

    @Test void revenueMatchesHandCalculation() {
        // 10000 + 2000 + 3000 + 8000 = 23000 cents.
        assertEquals(23000L, sample().accept(new RevenueVisitor()));
    }

    @Test void inventoryAccumulatesAcrossEntireTree() {
        InventoryVisitor visitor = new InventoryVisitor();
        sample().accept(visitor);
        assertEquals(Map.of("Areas", 2, "Gates", 2, "Flights", 2, "Lounges", 1, "Shops", 1), visitor.counts());
    }

    @Test void filterReturnsActualMatchingElements() {
        List<AirportElement> matches = sample().accept(new FilterVisitor(
                element -> element instanceof Flight flight && flight.passengers() >= 90));
        assertEquals(List.of("F1"), matches.stream().map(AirportElement::id).toList());
    }

    @Test void filterCanSelectContainersAsWellAsLeaves() {
        assertEquals(2, sample().accept(new FilterVisitor(element -> element instanceof Gate)).size());
    }

    @Test void jsonHasExactNestedStructure() {
        AirportArea root = new AirportArea("A", "Airport", List.of(new Gate("G", "Gate", List.of(
                new Shop("S", "Shop", 25)))));
        String expected = "{\"type\":\"area\",\"id\":\"A\",\"name\":\"Airport\",\"children\":["
                + "{\"type\":\"gate\",\"id\":\"G\",\"name\":\"Gate\",\"children\":["
                + "{\"type\":\"shop\",\"id\":\"S\",\"name\":\"Shop\",\"revenueCents\":25}]}]}";
        assertEquals(expected, root.accept(new JsonExportVisitor()));
    }

    @Test void jsonEscapesQuotesBackslashesAndControlCharacters() {
        Shop shop = new Shop("S", "A\"\\\n\r\t\u0001", 0);
        assertEquals("{\"type\":\"shop\",\"id\":\"S\",\"name\":\"A\\\"\\\\\\n\\r\\t\\u0001\",\"revenueCents\":0}",
                shop.accept(new JsonExportVisitor()));
    }

    @Test void emptyTreeHasZeroRevenueAndNoMatches() {
        Gate empty = new Gate("G", "Gate", List.of());
        assertEquals(0L, empty.accept(new RevenueVisitor()));
        assertTrue(empty.accept(new FilterVisitor(element -> element instanceof Flight)).isEmpty());
        assertTrue(empty.accept(new JsonExportVisitor()).endsWith("\"children\":[]}"));
    }

    @Test void containerDefensivelyCopiesChildren() {
        List<AirportElement> children = new ArrayList<>();
        Gate gate = new Gate("G", "Gate", children);
        children.add(new Shop("S", "Shop", 100));
        assertTrue(gate.children().isEmpty());
        assertThrows(UnsupportedOperationException.class, () -> gate.children().clear());
    }

    @Test void negativePassengerCountIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new Flight("F", "Flight", -1, 0));
    }

    @Test void negativeRevenueIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new Shop("S", "Shop", -1));
    }
}
