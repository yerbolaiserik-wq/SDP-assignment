package com.example.airport.tree;

import com.example.airport.visitor.Visitor;

public interface AirportElement {
    String id();
    String name();
    <R> R accept(Visitor<R> visitor);
}
