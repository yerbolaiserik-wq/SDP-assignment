package com.example.airport;

import com.example.airport.observer.*;
import com.example.airport.tree.AirportElement;
import com.example.airport.visitor.Visitor;
import java.util.Map;
import java.util.Objects;

public final class InspectionService implements Observer<AirportEvent> {
    private final Map<String, AirportElement> subtrees;
    private final Subject<AirportEvent> reports;
    private final Visitor<Long> revenueVisitor;

    public InspectionService(Map<String, AirportElement> subtrees, Subject<AirportEvent> reports,
                             Visitor<Long> revenueVisitor) {
        this.subtrees = Map.copyOf(subtrees);
        this.reports = Objects.requireNonNull(reports);
        this.revenueVisitor = Objects.requireNonNull(revenueVisitor);
    }

    @Override
    public void onEvent(AirportEvent event) {
        AirportElement subtree = subtrees.get(event.subtreeId());
        if (subtree == null) {
            throw new IllegalArgumentException("Unknown airport location: " + event.subtreeId());
        }
        long revenue = subtree.accept(revenueVisitor);
        reports.publish(new AirportEvent(EventType.INSPECTION_REPORT, "Gate inspection",
                subtree.id(), "Revenue report for " + subtree.name(), revenue));
    }
}
