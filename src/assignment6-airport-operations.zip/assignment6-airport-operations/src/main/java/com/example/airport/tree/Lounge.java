package com.example.airport.tree;

import com.example.airport.visitor.Visitor;
import java.util.Objects;

public record Lounge(String id, String name, int guests, long revenueCents) implements AirportElement {
    public Lounge {
        Objects.requireNonNull(id);
        Objects.requireNonNull(name);
        if (guests < 0 || revenueCents < 0) {
            throw new IllegalArgumentException("Guests and revenue must not be negative.");
        }
    }

    @Override
    public <R> R accept(Visitor<R> visitor) {
        return visitor.visit(this);
    }
}
