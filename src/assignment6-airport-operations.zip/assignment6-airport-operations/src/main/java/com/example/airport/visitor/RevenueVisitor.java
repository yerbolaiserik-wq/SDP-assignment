package com.example.airport.visitor;

import com.example.airport.tree.*;
import java.util.List;

public final class RevenueVisitor implements Visitor<Long> {
    private long total(List<AirportElement> elements) {
        long totalRevenue = 0;
        for (AirportElement element : elements) {
            totalRevenue += element.accept(this);
        }
        return totalRevenue;
    }

    @Override
    public Long visit(AirportArea area) {
        return total(area.children());
    }

    @Override
    public Long visit(Gate gate) {
        return total(gate.children());
    }

    @Override
    public Long visit(Flight flight) {
        return flight.revenueCents();
    }

    @Override
    public Long visit(Lounge lounge) {
        return lounge.revenueCents();
    }

    @Override
    public Long visit(Shop shop) {
        return shop.revenueCents();
    }

    @Override
    public Long visit(ParkingStand stand) {
        return stand.feeCents();
    }
}
