package com.example.airport;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.*;

public final class ProducerRunner implements AutoCloseable {
    private final ExecutorService executor;

    public ProducerRunner(ExecutorService executor) {
        this.executor = Objects.requireNonNull(executor);
    }

    public void runAll(List<Runnable> producers) throws InterruptedException {
        List<Future<?>> futures = new ArrayList<>();
        for (Runnable producer : producers) {
            futures.add(executor.submit(producer));
        }
        RuntimeException failure = null;
        for (Future<?> future : futures) {
            try {
                // Wait for this producer before checking the next one.
                future.get();
            } catch (ExecutionException error) {
                if (failure == null) {
                    failure = new IllegalStateException("A producer failed.");
                }
                failure.addSuppressed(error.getCause());
            }
        }
        if (failure != null) {
            throw failure;
        }
    }

    @Override
    public void close() throws InterruptedException {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(30, TimeUnit.SECONDS)) {
                executor.shutdownNow();
                throw new IllegalStateException("Producers did not finish within 30 seconds.");
            }
        } catch (InterruptedException error) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
            throw error;
        }
    }
}
