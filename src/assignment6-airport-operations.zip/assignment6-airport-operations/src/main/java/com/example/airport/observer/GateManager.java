package com.example.airport.observer;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class GateManager implements Observer<AirportEvent> {
    private final Map<String, String> gates = new ConcurrentHashMap<>();

    @Override
    public void onEvent(AirportEvent event) {
        gates.put(event.subtreeId(), event.message());
    }

    public Map<String, String> gates() {
        return Map.copyOf(gates);
    }
}
