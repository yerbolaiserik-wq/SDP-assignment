package com.example.airport.observer;

public interface TypedEvent {
    EventType type();
}
