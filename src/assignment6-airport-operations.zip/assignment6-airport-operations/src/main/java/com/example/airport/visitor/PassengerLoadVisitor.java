package com.example.airport.visitor;

import com.example.airport.tree.*;
import java.util.List;

public final class PassengerLoadVisitor implements Visitor<Integer> {
    private int total(List<AirportElement> children) {
        int people = 0;
        for (AirportElement child : children) {
            people += child.accept(this);
        }
        return people;
    }

    @Override
    public Integer visit(AirportArea area) {
        return total(area.children());
    }

    @Override
    public Integer visit(Gate gate) {
        return total(gate.children());
    }

    @Override
    public Integer visit(Flight flight) {
        return flight.passengers();
    }

    @Override
    public Integer visit(Lounge lounge) {
        return lounge.guests();
    }

    @Override
    public Integer visit(Shop shop) {
        return 0;
    }

    @Override
    public Integer visit(ParkingStand stand) {
        return 0;
    }
}
