package com.example.airport.tree;

import com.example.airport.visitor.Visitor;
import java.util.Objects;

public record Flight(String id, String name, int passengers, long revenueCents) implements AirportElement {
    public Flight {
        Objects.requireNonNull(id);
        Objects.requireNonNull(name);
        if (passengers < 0 || revenueCents < 0) {
            throw new IllegalArgumentException("Passengers and revenue must not be negative.");
        }
    }

    @Override
    public <R> R accept(Visitor<R> visitor) {
        return visitor.visit(this);
    }
}
