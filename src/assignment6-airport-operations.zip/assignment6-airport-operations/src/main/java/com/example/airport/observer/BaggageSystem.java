package com.example.airport.observer;

import java.util.concurrent.atomic.LongAdder;

public final class BaggageSystem implements Observer<AirportEvent> {
    private final LongAdder updates = new LongAdder();

    @Override
    public void onEvent(AirportEvent event) {
        updates.increment();
    }

    public long updates() {
        return updates.sum();
    }
}
