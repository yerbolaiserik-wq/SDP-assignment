package com.example.airport.visitor;

import com.example.airport.tree.*;

public interface Visitor<R> {
    R visit(AirportArea area);
    R visit(Gate gate);
    R visit(Flight flight);
    R visit(Lounge lounge);
    R visit(Shop shop);
    R visit(ParkingStand stand);
}
