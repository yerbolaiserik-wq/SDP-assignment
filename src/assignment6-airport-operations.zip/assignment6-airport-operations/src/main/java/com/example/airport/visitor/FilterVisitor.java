package com.example.airport.visitor;

import com.example.airport.tree.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

public final class FilterVisitor implements Visitor<List<AirportElement>> {
    private final Predicate<AirportElement> predicate;

    public FilterVisitor(Predicate<AirportElement> predicate) {
        this.predicate = Objects.requireNonNull(predicate);
    }

    private List<AirportElement> collect(AirportElement element, List<AirportElement> children) {
        List<AirportElement> matches = new ArrayList<>();
        if (predicate.test(element)) {
            matches.add(element);
        }
        for (AirportElement child : children) {
            matches.addAll(child.accept(this));
        }
        return List.copyOf(matches);
    }

    @Override
    public List<AirportElement> visit(AirportArea area) {
        return collect(area, area.children());
    }

    @Override
    public List<AirportElement> visit(Gate gate) {
        return collect(gate, gate.children());
    }

    @Override
    public List<AirportElement> visit(Flight flight) {
        return collect(flight, List.of());
    }

    @Override
    public List<AirportElement> visit(Lounge lounge) {
        return collect(lounge, List.of());
    }

    @Override
    public List<AirportElement> visit(Shop shop) {
        return collect(shop, List.of());
    }

    @Override
    public List<AirportElement> visit(ParkingStand stand) {
        return collect(stand, List.of());
    }
}
