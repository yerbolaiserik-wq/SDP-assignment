package com.example.airport.observer;

import java.util.Objects;

public record AirportEvent(EventType type, String source, String subtreeId,
                          String message, long value) implements TypedEvent {
    public AirportEvent {
        Objects.requireNonNull(type);
        Objects.requireNonNull(source);
        Objects.requireNonNull(subtreeId);
        Objects.requireNonNull(message);
    }
}
