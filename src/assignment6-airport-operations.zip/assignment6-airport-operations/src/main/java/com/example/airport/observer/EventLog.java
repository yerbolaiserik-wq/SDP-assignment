package com.example.airport.observer;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class EventLog implements Observer<AirportEvent> {
    private final ConcurrentLinkedQueue<AirportEvent> events = new ConcurrentLinkedQueue<>();

    @Override
    public void onEvent(AirportEvent event) {
        events.add(event);
    }

    public List<AirportEvent> events() {
        return List.copyOf(events);
    }
}
