package com.example.airport.observer;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class DepartureBoard implements Observer<AirportEvent> {
    private final Map<String, String> messages = new ConcurrentHashMap<>();

    @Override
    public void onEvent(AirportEvent event) {
        messages.put(event.subtreeId(), event.message());
    }

    public Map<String, String> messages() {
        return Map.copyOf(messages);
    }
}
