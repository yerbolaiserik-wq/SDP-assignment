package com.example.airport.observer;

public enum EventType {
    FLIGHT_STATUS, GATE_STATUS, TERMINAL_SUMMARY, INSPECTION_REPORT
}
