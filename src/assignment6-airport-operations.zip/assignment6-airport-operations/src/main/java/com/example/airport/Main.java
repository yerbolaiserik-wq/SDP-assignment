package com.example.airport;

import com.example.airport.observer.*;
import com.example.airport.tree.*;
import com.example.airport.visitor.*;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.concurrent.Executors;

public final class Main {
    // This is the composition root: all application objects are connected here.
    public static void main(String[] args) throws InterruptedException {
        int threads = 3;
        boolean showJson = false;
        for (String argument : args) {
            if (argument.equals("--json")) {
                showJson = true;
            } else {
                threads = Integer.parseInt(argument);
            }
        }
        if (threads < 1) {
            throw new IllegalArgumentException("Thread count must be positive.");
        }

        // 1. Build the sample airport: airport -> terminal -> gates -> leaves.
        Gate gateA = createGateA();
        Gate gateB = createGateB();
        AirportArea terminal = new AirportArea("T1", "Terminal 1", List.of(gateA, gateB));
        AirportArea airport = new AirportArea("ALA", "Almaty Airport", List.of(
                terminal));

        // 2. Create the sources and the objects that will listen to them.
        EventSource<AirportEvent> flightSource = new EventSource<>();
        EventSource<AirportEvent> gateSource = new EventSource<>();
        EventSource<AirportEvent> reportSource = new EventSource<>();
        DepartureBoard board = new DepartureBoard();
        PassengerNotifier passengers = new PassengerNotifier();
        GateManager manager = new GateManager();
        BaggageSystem baggage = new BaggageSystem();
        TerminalAggregator aggregator = new TerminalAggregator();
        EventLog log = new EventLog();
        InspectionService inspection = new InspectionService(Map.of("A1", gateA, "B1", gateB), reportSource,
                new RevenueVisitor());

        // 3. Subscribe listeners to the event types they need.
        flightSource.subscribe(EventType.FLIGHT_STATUS, board);
        flightSource.subscribe(EventType.FLIGHT_STATUS, passengers);
        flightSource.subscribe(EventType.FLIGHT_STATUS, baggage);
        flightSource.subscribe(EventType.FLIGHT_STATUS, aggregator);
        flightSource.subscribe(EventType.FLIGHT_STATUS, inspection);
        gateSource.subscribe(EventType.GATE_STATUS, manager);
        gateSource.subscribe(EventType.GATE_STATUS, aggregator);
        gateSource.subscribe(EventType.GATE_STATUS, inspection);
        aggregator.subscribe(EventType.TERMINAL_SUMMARY, log);
        reportSource.subscribe(EventType.INSPECTION_REPORT, log);

        // 4. Publish three updates, then wait for all listeners to finish.
        runUpdates(threads, flightSource, gateSource);

        System.out.println("Airport operations");
        System.out.println("Worker threads: " + threads);
        printUpdates(passengers, manager, baggage, aggregator, log);
        printVisitorResults(airport);
        if (showJson) {
            System.out.println("\n4. JSON export");
            System.out.println(airport.accept(new JsonExportVisitor()));
        }
    }

    private static Gate createGateA() {
        Flight flight = new Flight("KC101", "Flight KC101", 100, 1_000_000);
        Lounge lounge = new Lounge("L1", "Business lounge", 20, 50_000);
        Shop shop = new Shop("S1", "Coffee shop", 30_000);
        ParkingStand stand = new ParkingStand("P1", "Aircraft stand 1", 20_000);
        return new Gate("A1", "Gate A1", List.of(flight, lounge, shop, stand));
    }

    private static Gate createGateB() {
        Flight flight = new Flight("KC202", "Flight KC202", 80, 800_000);
        return new Gate("B1", "Gate B1", List.of(flight));
    }

    private static void runUpdates(int threads, EventSource<AirportEvent> flightSource,
                                   EventSource<AirportEvent> gateSource) throws InterruptedException {
        Runnable boardingUpdate = () -> flightSource.publish(new AirportEvent(
                EventType.FLIGHT_STATUS, "Flight feed", "A1", "KC101 is boarding at A1", 1));
        Runnable delayUpdate = () -> flightSource.publish(new AirportEvent(
                EventType.FLIGHT_STATUS, "Flight feed", "B1", "KC202 is delayed by 15 minutes", 1));
        Runnable gateUpdate = () -> gateSource.publish(new AirportEvent(
                EventType.GATE_STATUS, "Gate feed", "A1", "Gate A1 is open", 1));
        try (ProducerRunner runner = new ProducerRunner(Executors.newFixedThreadPool(threads))) {
            runner.runAll(List.of(boardingUpdate, delayUpdate, gateUpdate));
        }
    }

    private static void printUpdates(PassengerNotifier passengers, GateManager manager,
                                      BaggageSystem baggage, TerminalAggregator aggregator, EventLog log) {
        System.out.println("\n1. Updates received by listeners");
        for (String notice : passengers.notifications()) {
            System.out.println(notice);
        }
        for (String gateMessage : manager.gates().values()) {
            System.out.println(gateMessage);
        }
        System.out.println("Flight updates sent to baggage staff: " + baggage.updates());
        System.out.println("Updates for Gate A1: " + aggregator.count("A1"));
        System.out.println("Updates for Gate B1: " + aggregator.count("B1"));

        System.out.println("\n2. Gate revenue after each update");
        for (AirportEvent event : log.events()) {
            if (event.type() == EventType.INSPECTION_REPORT) {
                System.out.println("Gate " + event.subtreeId() + ": " + money(event.value()));
            }
        }
    }

    private static void printVisitorResults(AirportArea airport) {
        System.out.println("\n3. Whole airport report");
        System.out.println("Total revenue: " + money(airport.accept(new RevenueVisitor())));
        System.out.println("Passengers and lounge guests: " + airport.accept(new PassengerLoadVisitor()));

        List<AirportElement> busyFlights = airport.accept(new FilterVisitor(
                element -> element instanceof Flight flight && flight.passengers() >= 90));
        System.out.println("Flights with 90 or more passengers:");
        for (AirportElement flight : busyFlights) {
            System.out.println("  " + flight.name());
        }

        InventoryVisitor inventory = new InventoryVisitor();
        airport.accept(inventory);
        Map<String, Integer> counts = inventory.counts();
        System.out.println("Objects in the airport:");
        for (String type : List.of("Areas", "Gates", "Flights", "Lounges", "Shops", "Parking stands")) {
            System.out.println("  " + type + ": " + counts.getOrDefault(type, 0));
        }
    }

    private static String money(long cents) {
        return String.format(Locale.ROOT, "$%,.2f", cents / 100.0);
    }
}
