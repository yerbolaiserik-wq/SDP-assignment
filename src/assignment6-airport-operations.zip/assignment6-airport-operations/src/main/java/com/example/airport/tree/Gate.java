package com.example.airport.tree;

import com.example.airport.visitor.Visitor;
import java.util.List;
import java.util.Objects;

public record Gate(String id, String name, List<AirportElement> children) implements AirportElement {
    public Gate {
        Objects.requireNonNull(id);
        Objects.requireNonNull(name);
        children = List.copyOf(children);
    }

    @Override
    public <R> R accept(Visitor<R> visitor) {
        return visitor.visit(this);
    }
}
