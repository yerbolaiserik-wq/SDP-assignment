package com.example.airport.observer;

@FunctionalInterface
public interface Observer<E extends TypedEvent> {
    void onEvent(E event);
}
