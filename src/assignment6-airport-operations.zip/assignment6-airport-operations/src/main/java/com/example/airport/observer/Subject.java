package com.example.airport.observer;

public interface Subject<E extends TypedEvent> {
    void subscribe(EventType type, Observer<E> listener);
    void unsubscribe(EventType type, Observer<E> listener);
    void publish(E event);
}
