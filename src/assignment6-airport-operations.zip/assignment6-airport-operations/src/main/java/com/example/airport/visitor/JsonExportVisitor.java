package com.example.airport.visitor;

import com.example.airport.tree.*;
import java.util.List;

public final class JsonExportVisitor implements Visitor<String> {
    private String quote(String text) {
        StringBuilder result = new StringBuilder("\"");
        for (char c : text.toCharArray()) {
            switch (c) {
                case '"' -> result.append("\\\"");
                case '\\' -> result.append("\\\\");
                case '\n' -> result.append("\\n");
                case '\r' -> result.append("\\r");
                case '\t' -> result.append("\\t");
                default -> {
                    if (c < 32) {
                        result.append(String.format("\\u%04x", (int) c));
                    } else {
                        result.append(c);
                    }
                }
            }
        }
        return result.append('"').toString();
    }

    private String fields(String type, AirportElement element) {
        return "\"type\":" + quote(type) + ",\"id\":" + quote(element.id())
                + ",\"name\":" + quote(element.name());
    }

    private String container(String type, AirportElement element, List<AirportElement> children) {
        StringBuilder nested = new StringBuilder();
        for (int index = 0; index < children.size(); index++) {
            if (index > 0) {
                nested.append(",");
            }
            AirportElement child = children.get(index);
            nested.append(child.accept(this));
        }
        return "{" + fields(type, element) + ",\"children\":[" + nested + "]}";
    }

    @Override
    public String visit(AirportArea area) {
        return container("area", area, area.children());
    }

    @Override
    public String visit(Gate gate) {
        return container("gate", gate, gate.children());
    }

    @Override
    public String visit(Flight flight) {
        return "{" + fields("flight", flight) + ",\"passengers\":" + flight.passengers()
                + ",\"revenueCents\":" + flight.revenueCents() + "}";
    }
    @Override
    public String visit(Lounge lounge) {
        return "{" + fields("lounge", lounge) + ",\"guests\":" + lounge.guests()
                + ",\"revenueCents\":" + lounge.revenueCents() + "}";
    }
    @Override
    public String visit(Shop shop) {
        return "{" + fields("shop", shop) + ",\"revenueCents\":" + shop.revenueCents() + "}";
    }
    @Override
    public String visit(ParkingStand stand) {
        return "{" + fields("parkingStand", stand) + ",\"feeCents\":" + stand.feeCents() + "}";
    }
}
