package com.example.airport.observer;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class TerminalAggregator extends EventSource<AirportEvent> implements Observer<AirportEvent> {
    private final Map<String, Long> counts = new ConcurrentHashMap<>();

    @Override
    public void onEvent(AirportEvent event) {
        if (event.type() != EventType.FLIGHT_STATUS && event.type() != EventType.GATE_STATUS) {
            return;
        }
        long count = counts.merge(event.subtreeId(), 1L, Long::sum);
        publish(new AirportEvent(EventType.TERMINAL_SUMMARY, "Terminal summary",
                event.subtreeId(), "Updates received for " + event.subtreeId(), count));
    }

    public long count(String subtreeId) {
        return counts.getOrDefault(subtreeId, 0L);
    }
}
