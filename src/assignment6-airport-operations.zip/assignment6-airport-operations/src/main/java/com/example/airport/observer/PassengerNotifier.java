package com.example.airport.observer;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class PassengerNotifier implements Observer<AirportEvent> {
    private final ConcurrentLinkedQueue<String> notifications = new ConcurrentLinkedQueue<>();

    @Override
    public void onEvent(AirportEvent event) {
        notifications.add("Passenger notice: " + event.message());
    }

    public List<String> notifications() {
        return List.copyOf(notifications);
    }
}
