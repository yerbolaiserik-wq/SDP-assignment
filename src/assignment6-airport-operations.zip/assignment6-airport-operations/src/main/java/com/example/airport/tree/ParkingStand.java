package com.example.airport.tree;

import com.example.airport.visitor.Visitor;
import java.util.Objects;

public record ParkingStand(String id, String name, long feeCents) implements AirportElement {
    public ParkingStand {
        Objects.requireNonNull(id);
        Objects.requireNonNull(name);
        if (feeCents < 0) {
            throw new IllegalArgumentException("Aircraft parking fee must not be negative.");
        }
    }

    @Override
    public <R> R accept(Visitor<R> visitor) {
        return visitor.visit(this);
    }
}
