package com.example.airport.tree;

import com.example.airport.visitor.Visitor;
import java.util.Objects;

public record Shop(String id, String name, long revenueCents) implements AirportElement {
    public Shop {
        Objects.requireNonNull(id);
        Objects.requireNonNull(name);
        if (revenueCents < 0) {
            throw new IllegalArgumentException("Revenue must not be negative.");
        }
    }

    @Override
    public <R> R accept(Visitor<R> visitor) {
        return visitor.visit(this);
    }
}
