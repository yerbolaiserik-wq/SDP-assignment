package com.example.airport.visitor;

import com.example.airport.tree.*;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class InventoryVisitor implements Visitor<Void> {
    private final Map<String, Integer> counts = new LinkedHashMap<>();

    private void count(String type) {
        int previousCount = counts.getOrDefault(type, 0);
        counts.put(type, previousCount + 1);
    }

    private Void children(List<AirportElement> elements) {
        for (AirportElement element : elements) {
            element.accept(this);
        }
        return null;
    }

    // Void means the result is stored in counts, rather than returned from each visit.
    @Override
    public Void visit(AirportArea area) {
        count("Areas");
        return children(area.children());
    }

    @Override
    public Void visit(Gate gate) {
        count("Gates");
        return children(gate.children());
    }

    @Override
    public Void visit(Flight flight) {
        count("Flights");
        return null;
    }

    @Override
    public Void visit(Lounge lounge) {
        count("Lounges");
        return null;
    }

    @Override
    public Void visit(Shop shop) {
        count("Shops");
        return null;
    }

    @Override
    public Void visit(ParkingStand stand) {
        count("Parking stands");
        return null;
    }

    public Map<String, Integer> counts() {
        return Map.copyOf(counts);
    }
}
