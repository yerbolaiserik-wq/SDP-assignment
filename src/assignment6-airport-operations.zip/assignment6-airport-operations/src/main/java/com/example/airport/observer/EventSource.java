package com.example.airport.observer;

import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

public class EventSource<E extends TypedEvent> implements Subject<E> {
    private final Map<EventType, CopyOnWriteArrayList<Observer<E>>> listeners;

    public EventSource() {
        Map<EventType, CopyOnWriteArrayList<Observer<E>>> registry = new EnumMap<>(EventType.class);
        for (EventType type : EventType.values()) {
            registry.put(type, new CopyOnWriteArrayList<>());
        }
        listeners = Map.copyOf(registry);
    }

    @Override
    public void subscribe(EventType type, Observer<E> listener) {
        CopyOnWriteArrayList<Observer<E>> subscribers = listeners.get(Objects.requireNonNull(type));
        subscribers.addIfAbsent(Objects.requireNonNull(listener));
    }

    @Override
    public void unsubscribe(EventType type, Observer<E> listener) {
        CopyOnWriteArrayList<Observer<E>> subscribers = listeners.get(Objects.requireNonNull(type));
        subscribers.remove(Objects.requireNonNull(listener));
    }

    @Override
    public void publish(E event) {
        Objects.requireNonNull(event);
        RuntimeException failure = null;
        // Each publication sees a stable snapshot, even if a callback changes subscriptions.
        for (Observer<E> listener : listeners.get(event.type())) {
            try {
                listener.onEvent(event);
            } catch (RuntimeException error) {
                // Keep notifying the other listeners, then report all failures to the producer.
                if (failure == null) {
                    failure = new IllegalStateException("One or more listeners failed.");
                }
                failure.addSuppressed(error);
            }
        }
        if (failure != null) {
            throw failure;
        }
    }
}
